package com.example.myapp

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.util.Base64
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.text.Editable
import android.text.TextWatcher
import org.json.JSONArray
import org.json.JSONObject
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.*
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.webkit.*
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private const val DESKTOP_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

class Fav(val n: String, val u: String, val c: Int)

private val FAVS = listOf(
    Fav("Google", "google.com", 0xFF4285F4.toInt()), Fav("YouTube", "youtube.com", 0xFFFF0033.toInt()),
    Fav("Gmail", "mail.google.com", 0xFFEA4335.toInt()), Fav("Maps", "maps.google.com", 0xFF34A853.toInt()),
    Fav("Drive", "drive.google.com", 0xFFF9AB00.toInt()), Fav("News", "news.google.com", 0xFF1A73E8.toInt()),
    Fav("Translate", "translate.google.com", 0xFF5B8DEF.toInt()), Fav("Photos", "photos.google.com", 0xFFFF7043.toInt())
)

// base color followed by four glow colors
private val PRESETS = arrayOf(
    intArrayOf(0xFFFFFFFF.toInt(), 0xFFFFFFFF.toInt(), 0xFFFFFFFF.toInt(), 0xFFFFFFFF.toInt(), 0xFFFFFFFF.toInt()),
    intArrayOf(0xFF03111F.toInt(), 0xFF00C2FF.toInt(), 0xFF0066FF.toInt(), 0xFF00E5A8.toInt(), 0xFF5B3DFF.toInt()),
    intArrayOf(0xFF1A0B1F.toInt(), 0xFFFF6B3D.toInt(), 0xFFFF3D77.toInt(), 0xFFFFC23D.toInt(), 0xFF9B3DFF.toInt()),
    intArrayOf(0xFF04140E.toInt(), 0xFF1FD18B.toInt(), 0xFF0A8F6E.toInt(), 0xFF9BE15D.toInt(), 0xFF00B3C7.toInt())
)

class Tab(val id: Int) {
    var kind = "home"   // home, site, history, bookmarks, downloads, settings
    var web: WebView? = null
    var title = "Start Page"
    var url = ""
    var isPrivate = false
    var group = ""
    var pinned = false
    var blockedCount = 0
    var savedImageCount = 0
}

class MainActivity : AppCompatActivity() {
    private lateinit var root: FrameLayout
    private lateinit var wall: ImageView
    private lateinit var ui: FrameLayout
    private lateinit var webHost: FrameLayout
    private lateinit var scroll: ScrollView
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var content: LinearLayout
    private lateinit var overlay: FrameLayout
    private lateinit var urlBox: EditText
    private lateinit var tabCount: TextView
    private lateinit var progress: ProgressBar
    private lateinit var cur: Tab
    private lateinit var bar: GlassLayout
    private lateinit var pillBox: GlassLayout
    private lateinit var handle: FrameLayout
    private var barShown = true
    private val barHandler = Handler(Looper.getMainLooper())
    private val hideRun = Runnable { hideBar() }
    private var padB = -1
    private val iconCache = HashMap<String, Bitmap>()
    private lateinit var prefs: SharedPreferences
    private var W = 0
    private var H = 0
    private var wallpaperLight = false
    private var nextId = 1
    private var desktop = false
    private var searchEngine = "Google"
    private var adBlockEnabled = true
    private var adBlockDisabledSites = mutableSetOf<String>()
    private var dataSaver = false
    private var readerEnabled = false
    private var readerFontSize = 20
    private var readerDark = false
    private var darkPageEnabled = false
    private var nightFilterEnabled = false
    private var suggestionsEnabled = true
    private var biometricLock = false
    private var rssCache = mutableListOf<JSONObject>()
    private var newsVisibleCount = 12
    private val blockedHosts = mutableSetOf<String>()
    private var suggestionPopup: PopupWindow? = null
    private var suggestionRunnable: Runnable? = null
    private var suggestionConnection: java.net.HttpURLConnection? = null
    private val tabs = mutableListOf<Tab>()
    private var history = mutableListOf<Array<String>>()
    private var marks = mutableListOf<Array<String>>()
    private var dls = mutableListOf<Array<String>>()
    private val handler = Handler(Looper.getMainLooper())
    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) setGallery(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        prefs = getSharedPreferences("app", MODE_PRIVATE)
        history = parse(prefs.getString("hist", null))
        marks = parse(prefs.getString("marks", null))
        dls = parse(prefs.getString("dls", null))
        desktop = prefs.getBoolean("desktop", false)
        try { assets.open("adblock_hosts.txt").bufferedReader().useLines { lines ->
            lines.map { it.trim().lowercase() }.filter { it.isNotBlank() && !it.startsWith("#") }.forEach { blockedHosts.add(it) }
        } } catch (_: Exception) { }
        searchEngine = prefs.getString("engine", "Google") ?: "Google"
        adBlockEnabled = prefs.getBoolean("adblock", true)
        adBlockDisabledSites = prefs.getStringSet("adblock_disabled_sites", emptySet())?.toMutableSet() ?: mutableSetOf()
        dataSaver = prefs.getBoolean("datasaver", false)
        readerEnabled = prefs.getBoolean("reader", false)
        readerFontSize = prefs.getInt("reader_font_size", 20).coerceIn(16, 26)
        readerDark = prefs.getBoolean("reader_dark", false)
        darkPageEnabled = prefs.getBoolean("darkpage", false)
        nightFilterEnabled = prefs.getBoolean("nightfilter", false)
        suggestionsEnabled = prefs.getBoolean("suggestions", true)
        biometricLock = prefs.getBoolean("biometric_lock", false)
        rssCache = try {
            val a = JSONArray(prefs.getString("rss_cache", "[]"))
            MutableList(a.length()) { a.getJSONObject(it) }
        } catch (_: Exception) { mutableListOf() }
        val dm = android.util.DisplayMetrics()
        windowManager.defaultDisplay.getRealMetrics(dm)
        W = dm.widthPixels
        H = dm.heightPixels
        cur = Tab(nextId++)
        if (prefs.getBoolean("private_active", false)) {
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
            WebStorage.getInstance().deleteAllData()
            try { WebView(this).apply { clearCache(true); destroy() } } catch (_: Exception) { }
            prefs.edit().putBoolean("private_active", false).apply()
        }
        restoreTabs()

        root = FrameLayout(this)
        wall = ImageView(this)
        wall.scaleType = ImageView.ScaleType.FIT_XY
        root.addView(wall, FrameLayout.LayoutParams(W, H))
        ui = FrameLayout(this)
        root.addView(ui, FrameLayout.LayoutParams(-1, -1))
        webHost = FrameLayout(this)
        ui.addView(webHost, FrameLayout.LayoutParams(-1, -1))
        scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        scroll.addView(content, FrameLayout.LayoutParams(-1, -2))
        scroll.setOnScrollChangeListener { _, _, _, _, _ -> invalidateGlass(content) }
        swipe = SwipeRefreshLayout(this)
        swipe.setColorSchemeColors(0xFF4DA3FF.toInt())
        swipe.setOnRefreshListener { if (cur.kind == "news") fetchNews(true) else swipe.isRefreshing = false }
        swipe.addView(scroll, ViewGroup.LayoutParams(-1, -1))
        ui.addView(swipe, FrameLayout.LayoutParams(-1, -1))
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        progress.progressTintList = ColorStateList.valueOf(0xFF4DA3FF.toInt())
        progress.visibility = View.GONE
        ui.addView(progress, FrameLayout.LayoutParams(-1, dp(3)))
        bar = buildBar()
        ui.addView(bar, FrameLayout.LayoutParams(-1, -2).apply {
            gravity = Gravity.BOTTOM
            setMargins(dp(12), 0, dp(12), dp(10))
        })
        handle = FrameLayout(this)
        val pillBar = View(this)
        pillBar.background = round(0x99FFFFFF.toInt(), 3)
        handle.addView(pillBar, FrameLayout.LayoutParams(dp(90), dp(5)).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; bottomMargin = dp(8) })
        handle.visibility = View.GONE
        handle.setOnClickListener { showBar() }
        ui.addView(handle, FrameLayout.LayoutParams(dp(150), dp(32)).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL })
        overlay = FrameLayout(this)
        ui.addView(overlay, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2401)
        }
        ViewCompat.setOnApplyWindowInsetsListener(ui) { v, ins ->
            val sb = ins.getInsets(WindowInsetsCompat.Type.systemBars())
            val imeB = ins.getInsets(WindowInsetsCompat.Type.ime()).bottom
            @Suppress("DEPRECATION")
            val legacy = ins.systemWindowInsetBottom
            val target = maxOf(sb.bottom, imeB, legacy)
            if (padB < 0 || target == padB) {
                padB = target
                v.setPadding(0, sb.top, 0, target)
            } else {
                val a = ValueAnimator.ofInt(padB, target)
                padB = target
                a.duration = 240
                a.interpolator = DecelerateInterpolator()
                a.addUpdateListener {
                    v.setPadding(0, sb.top, 0, it.animatedValue as Int)
                    invalidateGlass(bar)
                }
                a.start()
            }
            ins
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { goBack(true) }
        })
        applyWallpaper()
        render()
        tabs.filter { it.url.isNotBlank() }.forEach { tab -> tab.web?.loadUrl(tab.url) }
        fadeUp(bar, 150)
    }

    override fun onPause() {
        saveTabs()
        super.onPause()
    }

    override fun onStop() {
        saveTabs()
        super.onStop()
    }

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun w1() = LinearLayout.LayoutParams(0, dp(42), 1f)
    private fun topGap() = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) }
    private fun round(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun clean(s: String) = s.replace('\t', ' ').replace('\n', ' ')
    private fun host(u: String?): String = if (u == null) "" else (Uri.parse(u).host ?: u).removePrefix("www.")

    private fun tv(s: String, sp: Float, bold: Boolean = false, a: Float = 1f): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = sp
        t.setTextColor(if (wallpaperLight && cur.kind != "site") 0xFF172033.toInt() else Color.WHITE)
        t.alpha = a
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        return t
    }

    private fun pill(label: String, click: () -> Unit): TextView {
        val t = tv(label, 14f, true)
        t.setPadding(dp(18), dp(10), dp(18), dp(10))
        t.background = round(0x33FFFFFF, 20)
        t.setOnClickListener { click() }
        press(t)
        return t
    }

    private fun iconBtn(res: Int, click: () -> Unit): ImageButton {
        val b = ImageButton(this)
        b.setImageResource(res)
        b.setBackgroundResource(android.R.color.transparent)
        b.setOnClickListener { click() }
        press(b)
        return b
    }

    private fun card(inner: LinearLayout.() -> Unit): GlassLayout {
        val g = GlassLayout(this)
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(dp(16), dp(6), dp(16), dp(6))
        l.inner()
        g.addView(l, FrameLayout.LayoutParams(-1, -2))
        return g
    }

    private fun lead(color: Int, icon: Int, letter: String = ""): View {
        val sz = dp(40)
        if (icon != 0) {
            val iv = ImageView(this)
            iv.setImageResource(icon)
            iv.setPadding(dp(9), dp(9), dp(9), dp(9))
            iv.background = round(color, 12)
            iv.layoutParams = LinearLayout.LayoutParams(sz, sz)
            return iv
        }
        val t = tv(letter, 17f, true)
        t.gravity = Gravity.CENTER
        t.background = round(color, 12)
        t.layoutParams = LinearLayout.LayoutParams(sz, sz)
        return t
    }

    private fun row(lead: View, title: String, sub: String, extra: View?, click: (() -> Unit)? = null): LinearLayout {
        val r = LinearLayout(this)
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(10), 0, dp(10))
        r.addView(lead)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(12), 0, dp(8), 0)
        val a = tv(title, 15f, true)
        a.maxLines = 1
        a.ellipsize = TextUtils.TruncateAt.END
        val b = tv(sub, 12f, false, .65f)
        b.maxLines = 1
        b.ellipsize = TextUtils.TruncateAt.END
        col.addView(a)
        col.addView(b)
        r.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        if (extra != null) r.addView(extra)
        if (click != null) { r.setOnClickListener { click() }; press(r, .97f) }
        return r
    }

    private fun header(title: String, label: String? = null, act: () -> Unit = {}): LinearLayout {
        val h = LinearLayout(this)
        h.gravity = Gravity.CENTER_VERTICAL
        h.addView(tv(title, 32f, true), LinearLayout.LayoutParams(0, -2, 1f))
        if (label != null) h.addView(pill(label, act))
        return h
    }

    private fun label(s: String): TextView {
        val t = tv(s.uppercase(), 12.5f, true, .6f)
        t.setPadding(dp(8), dp(22), 0, dp(8))
        return t
    }

    private fun empty(s: String): TextView {
        val t = tv(s, 14f, false, .6f)
        t.setPadding(0, dp(14), 0, dp(14))
        return t
    }

    private fun invalidateGlass(v: View) {
        if (v is GlassLayout) v.invalidate()
        if (v is ViewGroup) for (i in 0 until v.childCount) invalidateGlass(v.getChildAt(i))
    }

    private fun showKeyboard() {
        urlBox.post { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(urlBox, InputMethodManager.SHOW_IMPLICIT) }
    }

    private fun hideKeyboard() {
        urlBox.clearFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(urlBox.windowToken, 0)
    }

    // ---------- animation + icons ----------
    @SuppressLint("ClickableViewAccessibility")
    private fun press(v: View, s: Float = .93f) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> view.animate().scaleX(s).scaleY(s).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(2.5f)).start()
            }
            false
        }
    }

    private fun fadeUp(v: View, delay: Long = 0) {
        val target = v.alpha
        v.alpha = 0f
        v.translationY = dp(18).toFloat()
        v.animate().alpha(target).translationY(0f).setStartDelay(delay).setDuration(360)
            .setInterpolator(DecelerateInterpolator(1.6f))
            .setUpdateListener { invalidateGlass(v) }
            .withEndAction { invalidateGlass(v) }
            .start()
    }

    private fun popSheet(v: View) {
        v.translationY = dp(36).toFloat()
        v.scaleX = .96f
        v.scaleY = .96f
        v.animate().translationY(0f).scaleX(1f).scaleY(1f).setDuration(400)
            .setInterpolator(OvershootInterpolator(.9f))
            .setUpdateListener { invalidateGlass(v) }
            .withEndAction { invalidateGlass(v) }
            .start()
    }

    private fun loadIcon(domain: String, iv: ImageView) {
        val d = domain.lowercase()
        if (d.isBlank()) return
        val hit = iconCache[d]
        if (hit != null) { iv.setImageBitmap(hit); iv.visibility = View.VISIBLE; return }
        Thread {
            var bm: Bitmap? = null
            try {
                val f = File(cacheDir, "ic_" + d.replace(Regex("[^a-z0-9.]"), "_") + ".png")
                if (f.exists()) bm = BitmapFactory.decodeFile(f.path)
                if (bm == null) {
                    val sources = listOf("https://icons.duckduckgo.com/ip3/$d.ico", "https://www.google.com/s2/favicons?domain=$d&sz=256")
                    for (source in sources) try {
                        val c = java.net.URL(source).openConnection() as java.net.HttpURLConnection
                        c.connectTimeout = 5000; c.readTimeout = 5000
                        c.setRequestProperty("User-Agent", "Mozilla/5.0 FluxBrowser")
                        val bytes = c.inputStream.use { it.readBytes() }; c.disconnect()
                        bm = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        if (bm != null) { f.writeBytes(bytes); break }
                    } catch (_: Exception) { }
                }
            } catch (e: Exception) { }
            val r = bm
            if (r != null) runOnUiThread { iconCache[d] = r; iv.setImageBitmap(r); iv.visibility = View.VISIBLE }
        }.start()
    }

    /** Real site logo on a white tile; shows `fallback` until the logo loads. */
    private fun favTile(domain: String, sz: Int, rad: Int, fallback: View): FrameLayout {
        val f = FrameLayout(this)
        f.addView(fallback, FrameLayout.LayoutParams(-1, -1))
        val iv = ImageView(this)
        iv.background = round(0xFFFFFFFF.toInt(), rad)
        val p = dp(sz / 5)
        iv.setPadding(p, p, p, p)
        iv.visibility = View.GONE
        f.addView(iv, FrameLayout.LayoutParams(-1, -1))
        loadIcon(domain, iv)
        f.layoutParams = LinearLayout.LayoutParams(dp(sz), dp(sz))
        return f
    }

    private fun hideBar() {
        if (!barShown || cur.kind != "site" || urlBox.hasFocus() || overlay.childCount > 0) return
        barShown = false
        bar.animate().translationY((bar.height + dp(40)).toFloat()).alpha(0f).setDuration(280)
            .setInterpolator(DecelerateInterpolator()).setUpdateListener { invalidateGlass(bar) }.start()
        handle.visibility = View.VISIBLE
        handle.alpha = 0f
        handle.animate().alpha(1f).setDuration(280).start()
    }

    private fun showBar() {
        if (barShown) return
        barShown = true
        bar.animate().translationY(0f).alpha(1f).setDuration(320)
            .setInterpolator(OvershootInterpolator(.8f)).setUpdateListener { invalidateGlass(bar) }.start()
        handle.animate().alpha(0f).setDuration(150).withEndAction { handle.visibility = View.GONE }.start()
    }

    // ---------- storage ----------
    private fun parse(s: String?): MutableList<Array<String>> =
        (s ?: "").split("\n").filter { it.isNotBlank() }.map { it.split("\t").toTypedArray() }.filter { it.size >= 2 }.toMutableList()

    private fun saveLists() {
        prefs.edit()
            .putString("hist", history.take(200).joinToString("\n") { it.joinToString("\t") })
            .putString("marks", marks.joinToString("\n") { it.joinToString("\t") })
            .putString("dls", dls.joinToString("\n") { it.joinToString("\t") })
            .apply()
    }

    private fun saveTabs() {
        if (!::prefs.isInitialized || tabs.isEmpty()) return
        val a = JSONArray()
        tabs.filter { !it.isPrivate }.forEach { t ->
            a.put(JSONObject().put("id", t.id).put("kind", t.kind).put("title", t.title)
                .put("url", t.web?.url ?: t.url).put("private", t.isPrivate)
                .put("group", t.group).put("pinned", t.pinned).put("current", t === cur))
        }
        prefs.edit().putString("tabs_v2", a.toString()).putInt("next_tab_id", nextId)
            .putBoolean("private_active", tabs.any { it.isPrivate }).apply()
    }

    private fun restoreTabs() {
        tabs.clear()
        val raw = prefs.getString("tabs_v2", null)
        if (!raw.isNullOrBlank()) try {
            val a = JSONArray(raw)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                if (o.optBoolean("private", false)) continue
                val t = Tab(o.optInt("id", nextId++))
                t.kind = o.optString("kind", "home")
                t.title = o.optString("title", "Start Page")
                t.url = o.optString("url", "")
                t.isPrivate = o.optBoolean("private", false)
                t.group = o.optString("group", "")
                t.pinned = o.optBoolean("pinned", false)
                if (t.url.isNotBlank()) {
                    t.web = newWeb(t)
                }
                tabs.add(t)
                if (o.optBoolean("current", false)) cur = t
                nextId = maxOf(nextId, t.id + 1)
            }
        } catch (_: Exception) { tabs.clear() }
        if (tabs.isEmpty()) tabs.add(Tab(nextId++))
        if (tabs.none { it === cur }) cur = tabs.first()
        nextId = maxOf(nextId, prefs.getInt("next_tab_id", 1))
    }

    private fun addHistory(t: String, u: String) {
        if (u.isEmpty() || u.startsWith("about:")) return
        if (history.isNotEmpty() && history[0][1] == u) return
        history.add(0, arrayOf(clean(t), clean(u), SimpleDateFormat("MMM d, h:mm a", Locale.ENGLISH).format(Date())))
        if (history.size > 300) history.removeAt(history.size - 1)
        saveLists()
    }

    // ---------- bottom bar ----------
    private fun buildBar(): GlassLayout {
        val bar = GlassLayout(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(10), dp(10), dp(10), dp(4))
        urlBox = EditText(this)
        urlBox.hint = "Search or enter address"
        urlBox.setHintTextColor(0x99FFFFFF.toInt())
        urlBox.setTextColor(Color.WHITE)
        urlBox.textSize = 16f
        urlBox.background = null
        urlBox.gravity = Gravity.CENTER
        urlBox.inputType = EditorInfo.TYPE_CLASS_TEXT or EditorInfo.TYPE_TEXT_VARIATION_URI
        urlBox.imeOptions = EditorInfo.IME_ACTION_GO
        urlBox.setSelectAllOnFocus(true)
        urlBox.setOnEditorActionListener { v, id, _ ->
            if (id == EditorInfo.IME_ACTION_GO) { go(v.text.toString()); true } else false
        }
        urlBox.addTextChangedListener(object : TextWatcher {
            private var request = 0
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val token = ++request
                suggestionRunnable?.let { handler.removeCallbacks(it) }
                suggestionConnection?.disconnect()
                suggestionPopup?.dismiss()
                if (!suggestionsEnabled || !urlBox.hasFocus() || s.isNullOrBlank() || s.length < 2) return
                val q = s.toString().trim()
                val local = (history.filter { it.getOrElse(0) { "" }.contains(q, true) || it.getOrElse(1) { "" }.contains(q, true) }
                    .take(3).map { it[0] + "  ·  History" } +
                    marks.filter { it.getOrElse(0) { "" }.contains(q, true) || it.getOrElse(1) { "" }.contains(q, true) }
                        .take(3).map { it[0] + "  ·  Bookmark" }).distinct()
                if (local.isNotEmpty()) showSuggestions(local)
                val task = Runnable {
                    Thread {
                        try {
                            val conn = (java.net.URL("https://suggestqueries.google.com/complete/search?client=firefox&q=" + Uri.encode(q)).openConnection() as java.net.HttpURLConnection)
                            suggestionConnection = conn
                            conn.connectTimeout = 3500; conn.readTimeout = 3500
                            val data = conn.inputStream.bufferedReader().use { it.readText() }
                            val arr = JSONArray(data).optJSONArray(1)
                            val opts = mutableListOf<String>()
                            if (arr != null) for (i in 0 until minOf(arr.length(), 6)) opts.add(arr.optString(i))
                            runOnUiThread {
                                if (token == request && urlBox.hasFocus() && opts.isNotEmpty()) showSuggestions((local + opts).distinct().take(8))
                            }
                            conn.disconnect()
                        } catch (_: Exception) { }
                    }.start()
                }
                suggestionRunnable = task
                handler.postDelayed(task, 280)
            }
            override fun afterTextChanged(s: Editable?) {}
        })
        urlBox.setOnLongClickListener {
            val clip = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            val item = clip.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()
            if (!item.isNullOrBlank() && (item.startsWith("http://") || item.startsWith("https://"))) {
                urlBox.setText(item)
                urlBox.setSelection(item.length)
                Toast.makeText(this, "Copied link pasted", Toast.LENGTH_SHORT).show()
            }
            false
        }
        urlBox.setOnFocusChangeListener { _, f ->
            if (f) { showBar(); barHandler.removeCallbacks(hideRun) }
            if (f && cur.kind == "site") { urlBox.setText(cur.url); urlBox.selectAll() }
            else if (!f) { suggestionPopup?.dismiss(); suggestionConnection?.disconnect(); urlBox.setText(if (cur.kind == "site") host(cur.url) else "") }
        }
        pillBox = GlassLayout(this)
        pillBox.elevation = 0f
        pillBox.addView(urlBox, FrameLayout.LayoutParams(-1, dp(44)))
        col.addView(pillBox)
        val row = LinearLayout(this)
        row.setPadding(0, dp(4), 0, 0)
        row.addView(iconBtn(R.drawable.ic_back) { goBack(false) }, w1())
        row.addView(iconBtn(R.drawable.ic_fwd) { goForward() }, w1())
        row.addView(iconBtn(R.drawable.ic_plus) { newTab() }, w1())
        val tf = FrameLayout(this)
        tf.addView(iconBtn(R.drawable.ic_tabs) { showTabs() }, FrameLayout.LayoutParams(-1, -1))
        tabCount = tv("1", 10f, true)
        tabCount.gravity = Gravity.CENTER
        tf.addView(tabCount, FrameLayout.LayoutParams(-1, -1))
        row.addView(tf, w1())
        row.addView(iconBtn(R.drawable.ic_menu) { showMenu() }, w1())
        col.addView(row)
        bar.addView(col, FrameLayout.LayoutParams(-1, -2))
        return bar
    }

    // ---------- navigation ----------
    private fun render() {
        webHost.removeAllViews()
        progress.visibility = View.GONE
        val w = cur.web
        val onSite = cur.kind == "site" && w != null
        swipe.isEnabled = cur.kind == "news"
        swipe.visibility = if (onSite) View.GONE else View.VISIBLE
        bar.overContent = onSite
        pillBox.overContent = onSite
        showBar()
        if (cur.kind == "site" && w != null) {
            webHost.addView(w, FrameLayout.LayoutParams(-1, -1))
            webHost.visibility = View.VISIBLE
            scroll.visibility = View.GONE
            urlBox.setText(host(cur.url))
            webHost.alpha = 0f
            webHost.animate().alpha(1f).setDuration(260).start()
        } else {
            webHost.visibility = View.GONE
            scroll.visibility = View.VISIBLE
            urlBox.setText("")
            buildPage(cur.kind)
        }
        val n = tabs.size.toString()
        if (tabCount.text.toString() != n) {
            tabCount.text = n
            tabCount.animate().scaleX(1.5f).scaleY(1.5f).setDuration(120).withEndAction {
                tabCount.animate().scaleX(1f).scaleY(1f).setDuration(240).setInterpolator(OvershootInterpolator(3f)).start()
            }.start()
        }
    }

    private fun go(q: String) {
        val s = q.trim()
        if (s.isEmpty()) return
        val isUrl = Regex("^(https?://)?[\\w-]+(\\.[\\w-]+)+(:\\d+)?(/.*)?$").matches(s)
        val base = when (searchEngine) {
            "DuckDuckGo" -> "https://duckduckgo.com/?q="
            "Bing" -> "https://www.bing.com/search?q="
            else -> "https://www.google.com/search?q="
        }
        val u = if (isUrl) (if (s.startsWith("http")) s else "https://$s") else base + Uri.encode(s)
        if (cur.web == null) cur.web = newWeb(cur)
        cur.kind = "site"
        render()
        cur.web!!.loadUrl(u)
        saveTabs()
        hideKeyboard()
    }

    private fun goBack(system: Boolean) {
        if (overlay.childCount > 0) { closeOverlay(); return }
        val w = cur.web
        if (cur.kind == "site") {
            if (w != null && w.canGoBack()) w.goBack() else { cur.kind = "home"; render() }
            saveTabs()
        } else if (cur.kind != "home") {
            cur.kind = if (w != null && cur.url.isNotEmpty()) "site" else "home"
            render()
        } else if (system) finish()
    }

    private fun goForward() {
        val w = cur.web ?: return
        if (cur.kind == "site") { if (w.canGoForward()) w.goForward() }
        else if (cur.url.isNotEmpty()) { cur.kind = "site"; render() }
    }

    private fun open(kind: String) {
        if (kind == "downloads" && biometricLock) {
            authenticate("Unlock downloads") { cur.kind = kind; render() }
            return
        }
        cur.kind = kind; render()
    }

    private fun openInNewTab(url: String, privateMode: Boolean) {
        if (privateMode && biometricLock) {
            authenticate("Unlock private tabs") {
                newTab(true, true)
                go(url)
            }
        } else {
            newTab(privateMode, true)
            go(url)
        }
    }

    private fun newTab(privateMode: Boolean = false, unlocked: Boolean = false) {
        if (privateMode && biometricLock && !unlocked) {
            authenticate("Unlock private tabs") { newTab(true, true) }
            return
        }
        cur = Tab(nextId++)
        cur.isPrivate = privateMode
        if (privateMode) Toast.makeText(this, "Private tabs share WebView storage; closing them clears shared cookies and site data.", Toast.LENGTH_LONG).show()
        tabs.add(cur)
        saveTabs()
        closeOverlay()
        render()
    }

    private fun closeTab(t: Tab) {
        val w = t.web
        if (w != null) { (w.parent as? ViewGroup)?.removeView(w) }
        tabs.remove(t)
        if (t.isPrivate) {
            Toast.makeText(this, "Private tab closed. Shared WebView cookies, cache and site storage were cleared for privacy.", Toast.LENGTH_LONG).show()
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
            WebStorage.getInstance().deleteAllData()
            tabs.forEach { it.web?.clearCache(true) }
        }
        if (w != null) w.destroy()
        if (tabs.isEmpty()) { cur = Tab(nextId++); tabs.add(cur) } else if (cur === t) cur = tabs.last()
        saveTabs()
        render()
    }

    private fun applyUa(w: WebView?) {
        if (w == null) return
        w.settings.userAgentString = if (desktop) DESKTOP_UA else null
        w.settings.useWideViewPort = desktop
        w.settings.loadWithOverviewMode = desktop
    }

    private fun setDesktop(on: Boolean) {
        desktop = on
        prefs.edit().putBoolean("desktop", on).apply()
        tabs.forEach { applyUa(it.web); it.web?.reload() }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun newWeb(t: Tab): WebView {
        val w = WebView(this)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.builtInZoomControls = true
        w.settings.displayZoomControls = false
        w.settings.loadsImagesAutomatically = true
        w.settings.javaScriptCanOpenWindowsAutomatically = false
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)
        applyUa(w)
        var lastY = 0f
        var acc = 0f
        w.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { lastY = e.rawY; acc = 0f }
                MotionEvent.ACTION_MOVE -> {
                    val dy = e.rawY - lastY
                    lastY = e.rawY
                    acc = if (acc * dy >= 0f) acc + dy else dy
                    if (acc < -dp(26)) hideBar() else if (acc > dp(26)) showBar()
                }
            }
            false
        }
        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val targetHost = request?.url?.host?.lowercase() ?: return false
                val sourceHost = host(t.url)
                val blockedNavigation = adBlockEnabled && sourceHost !in adBlockDisabledSites && blockedHosts.any { targetHost == it || targetHost.endsWith(".$it") }
                if (blockedNavigation) { t.blockedCount++; return true }
                return false
            }
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val u = request?.url?.host?.lowercase() ?: return null
                val siteHost = host(t.url)
                val blocked = adBlockEnabled && siteHost !in adBlockDisabledSites &&
                    (blockedHosts.any { u == it || u.endsWith(".$it") } || listOf("doubleclick.net", "googlesyndication.com", "adservice.google.com", "adnxs.com", "taboola.com", "outbrain.com", "popads.net", "popcash.net").any { u == it || u.endsWith(".$it") })
                if (blocked) {
                    t.blockedCount++
                    return WebResourceResponse("text/plain", "utf-8", java.io.ByteArrayInputStream(ByteArray(0)))
                }
                val path = request.url.path?.lowercase() ?: ""
                if (dataSaver && path.matches(Regex(".*\\.(png|jpe?g|gif|webp|avif|svg)(\\?.*)?$"))) {
                    t.savedImageCount++
                    return WebResourceResponse("text/plain", "utf-8", java.io.ByteArrayInputStream(ByteArray(0)))
                }
                return super.shouldInterceptRequest(view, request)
            }
            override fun onPageStarted(v: WebView?, u: String?, f: Bitmap?) {
                t.url = u ?: ""
                if (t === cur) {
                    progress.progress = 0
                    progress.visibility = View.VISIBLE
                    if (t.kind == "site" && !urlBox.hasFocus()) urlBox.setText(host(u))
                }
            }
            override fun onPageFinished(v: WebView?, u: String?) {
                t.title = v?.title ?: host(u)
                t.url = u ?: t.url
                if (t === cur) {
                    progress.visibility = View.GONE
                    barHandler.removeCallbacks(hideRun)
                    barHandler.postDelayed(hideRun, 1800)
                }
                if (!t.isPrivate) addHistory(t.title, t.url)
                if (adBlockEnabled && host(t.url) !in adBlockDisabledSites) applyAdBlockPage(v)
                if (readerEnabled) applyReaderMode(v)
                if (darkPageEnabled) applyPageTheme(v)
                if (nightFilterEnabled) applyNightFilter(v)
                installBlobCapture(v)
                v?.evaluateJavascript("""(function(){if(window.__fluxSelectionHook)return;window.__fluxSelectionHook=1;document.addEventListener('contextmenu',function(){var t=String(window.getSelection());if(t)FluxSelection.selected(t)},true)})();""", null)
                saveTabs()
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView?, p: Int) { if (t === cur) progress.progress = p }
            override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message?): Boolean = false
        }
        w.setDownloadListener { u, ua, cd, mime, _ -> startDownload(u, ua, cd, mime) }
        w.setOnLongClickListener {
            val hit = w.hitTestResult
            val target = hit.extra ?: ""
            if (target.isNotBlank()) {
                val isImage = hit.type == WebView.HitTestResult.IMAGE_TYPE || hit.type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE
                if (isImage) showActionSheet("Image actions", listOf(
                    "Open image in new tab" to { openInNewTab(target, false) },
                    "Download image" to { startDownload(target, w.settings.userAgentString, null, null) },
                    "Copy image link" to { copyText(target, "Image link copied") },
                    "Share image" to { shareText(target, "Share image") },
                    "Search image on Google" to { go("https://www.google.com/searchbyimage?image_url=" + Uri.encode(target)) }
                )) else showActionSheet("Link actions", listOf(
                    "Open link in new tab" to { openInNewTab(target, false) },
                    "Open link in private tab" to { openInNewTab(target, true) },
                    "Copy link" to { copyText(target, "Link copied") },
                    "Share link" to { shareText(target, "Share link") },
                    "Download link" to { startDownload(target, w.settings.userAgentString, null, null) }
                ))
                true
            } else false
        }
        w.addJavascriptInterface(object {
            @JavascriptInterface fun saveBlob(name: String, mime: String, data: String) {
                try {
                    val bytes = Base64.decode(data, Base64.DEFAULT)
                    val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_").take(100).ifBlank { "download.bin" }
                    saveBytesToDownloads(safe, mime, bytes)
                    runOnUiThread { Toast.makeText(this@MainActivity, "Saved to Downloads: $safe", Toast.LENGTH_LONG).show() }
                } catch (_: Exception) {}
            }
        }, "FluxDownloads")
        w.addJavascriptInterface(object {
            @JavascriptInterface fun selected(text: String) {
                runOnUiThread {
                    if (text.isNotBlank()) {
                        showActionSheet("Selected text", listOf(
                            "Copy text" to { copyText(text, "Text copied") },
                            "Share text" to { shareText(text, "Share text") },
                            "Search with Google" to { go("https://www.google.com/search?q=" + Uri.encode(text)) }
                        ))
                    }
                }
            }
        }, "FluxSelection")
        return w
    }

    private fun installBlobCapture(w: WebView?) {
        val js = """(function(){if(window.__fluxBlobHook)return;window.__fluxBlobHook=1;document.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('a');if(!a||!a.href||!a.href.startsWith('blob:'))return;e.preventDefault();fetch(a.href).then(r=>r.blob()).then(b=>{var fr=new FileReader();fr.onload=()=>FluxDownloads.saveBlob(a.download||'download.bin',b.type||'application/octet-stream',fr.result.split(',')[1]);fr.readAsDataURL(b)}).catch(()=>{});},true)})();"""
        w?.evaluateJavascript(js, null)
    }

    private fun saveBytesToDownloads(name: String, mime: String, bytes: ByteArray) {
        val values = android.content.ContentValues().apply {
            put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(android.provider.MediaStore.MediaColumns.MIME_TYPE, mime)
            put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            put(android.provider.MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Could not create download")
        try {
            contentResolver.openOutputStream(uri)?.use { it.write(bytes) } ?: throw IllegalStateException("Could not write download")
            val done = android.content.ContentValues().apply { put(android.provider.MediaStore.MediaColumns.IS_PENDING, 0) }
            contentResolver.update(uri, done, null, null)
            runOnUiThread { dls.add(0, arrayOf("uri:$uri", name)); saveLists() }
        } catch (e: Exception) {
            contentResolver.delete(uri, null, null)
            throw e
        }
    }

    private fun startDownload(u: String, ua: String?, cd: String?, mime: String?) {
        val name = URLUtil.guessFileName(u, cd, mime)
        try {
            if (u.startsWith("data:")) {
                val comma = u.indexOf(',')
                if (comma > 0) {
                    val meta = u.substring(0, comma)
                    val raw = u.substring(comma + 1)
                    val bytes = if (meta.contains(";base64")) Base64.decode(raw, Base64.DEFAULT) else Uri.decode(raw).toByteArray()
                    val safe = name.ifBlank { "download.bin" }.replace(Regex("[^A-Za-z0-9._-]"), "_")
                    val dataMime = meta.removePrefix("data:").substringBefore(';').ifBlank { mime ?: "application/octet-stream" }
                    saveBytesToDownloads(safe, dataMime, bytes)
                    Toast.makeText(this, "Saved to Downloads: $safe", Toast.LENGTH_LONG).show()
                    return
                }
            }
            if (u.startsWith("blob:")) {
                Toast.makeText(this, "Preparing browser download…", Toast.LENGTH_SHORT).show()
                cur.web?.evaluateJavascript("""(async function(){try{const r=await fetch('$u');const b=await r.blob();const a=await b.arrayBuffer();let s='';new Uint8Array(a).forEach(x=>s+=String.fromCharCode(x));FluxDownloads.saveBlob('${name.replace("'", "")}','${mime ?: "application/octet-stream"}',btoa(s));}catch(e){}})();""", null)
                return
            }
            val req = DownloadManager.Request(Uri.parse(u))
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            if (mime != null) req.setMimeType(mime)
            if (ua != null) req.addRequestHeader("User-Agent", ua)
            if (cur.url.isNotBlank()) req.addRequestHeader("Referer", cur.url)
            val ck = CookieManager.getInstance().getCookie(u)
            if (ck != null) req.addRequestHeader("Cookie", ck)
            val id = (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            dls.add(0, arrayOf(id.toString(), clean(name)))
            saveLists()
            Toast.makeText(this, "Downloading $name", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Download failed", Toast.LENGTH_SHORT).show()
        }
    }

    private fun clearData() {
        history.clear()
        saveLists()
        CookieManager.getInstance().removeAllCookies(null)
        WebStorage.getInstance().deleteAllData()
        tabs.forEach { it.web?.clearCache(true) }
        Toast.makeText(this, "Browsing data cleared", Toast.LENGTH_SHORT).show()
        if (cur.kind != "site") buildPage(cur.kind)
    }

    private fun addBookmark() {
        if (cur.kind == "site" && cur.url.isNotEmpty()) {
            if (marks.none { it[1] == cur.url }) marks.add(0, arrayOf(clean(cur.title), clean(cur.url)))
            saveLists()
            Toast.makeText(this, "Bookmark added", Toast.LENGTH_SHORT).show()
        } else Toast.makeText(this, "Open a website first", Toast.LENGTH_SHORT).show()
    }

    private fun authenticate(reason: String, success: () -> Unit) {
        val manager = BiometricManager.from(this)
        if (manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) != BiometricManager.BIOMETRIC_SUCCESS) {
            Toast.makeText(this, "Set up fingerprint or face unlock in Android settings first", Toast.LENGTH_LONG).show()
            return
        }
        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { success() }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { Toast.makeText(this@MainActivity, errString, Toast.LENGTH_SHORT).show() }
        })
        val info = BiometricPrompt.PromptInfo.Builder().setTitle(reason)
            .setSubtitle("Verify to continue").setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
            .setNegativeButtonText("Cancel").build()
        prompt.authenticate(info)
    }

    private fun toggleSetting(key: String, value: Boolean, apply: (Boolean) -> Unit) {
        prefs.edit().putBoolean(key, value).apply()
        apply(value)
    }

    private fun chooseSearchEngine() {
        val engines = arrayOf("Google", "DuckDuckGo", "Bing")
        AlertDialog.Builder(this).setTitle("Search engine").setSingleChoiceItems(engines, engines.indexOf(searchEngine)) { d, which ->
            searchEngine = engines[which]
            prefs.edit().putString("engine", searchEngine).apply()
            d.dismiss()
            buildPage("settings")
        }.setNegativeButton("Cancel", null).show()
    }

    private fun showSuggestions(items: List<String>) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(12), dp(8), dp(12), dp(8))
        items.forEach { value ->
            val t = tv(value, 14f)
            t.setPadding(dp(8), dp(9), dp(8), dp(9))
            t.setOnClickListener {
                val actual = value.substringBefore("  ·  ")
                val found = (history + marks).firstOrNull { it.getOrElse(0) { "" } == actual }
                if (found != null) go(found.getOrElse(1) { actual }) else { urlBox.setText(actual); urlBox.setSelection(actual.length); go(actual) }
            }
            box.addView(t)
        }
        val popup = PopupWindow(box, -1, -2, true)
        suggestionPopup = popup
        popup.setBackgroundDrawable(round(if (wallpaperLight) 0xF7FFFFFF.toInt() else 0xEE171923.toInt(), 14))
        popup.elevation = dp(12).toFloat()
        try { popup.showAsDropDown(urlBox) } catch (_: Exception) {}
        handler.postDelayed({ if (popup.isShowing) popup.dismiss() }, 4500)
    }

    private fun applyAdBlockPage(w: WebView?) {
        val js = """(function(){if(window.__fluxAdCss)return;window.__fluxAdCss=1;var s=document.createElement('style');s.id='flux-ad-css';s.textContent='[id*=\"google_ads\" i],[class*=\"advert\" i],[class*=\"sponsor\" i],[id*=\"ad-container\" i],iframe[src*=\"doubleclick\"],iframe[src*=\"googlesyndication\"]{display:none!important;visibility:hidden!important;height:0!important;width:0!important}';(document.head||document.documentElement).appendChild(s);var old=window.open;window.open=function(){return null};document.querySelectorAll('meta[http-equiv=\"refresh\" i]').forEach(x=>x.remove());})();"""
        w?.evaluateJavascript(js, null)
    }

    private fun applyReaderMode(w: WebView? = cur.web) {
        if (w == null) return
        val bg = if (readerDark) "#15171c" else "#faf7ef"
        val fg = if (readerDark) "#eeeeee" else "#222222"
        val js = if (readerEnabled) """(function(){if(window.__fluxReaderActive)return;window.__fluxReaderActive=true;window.__fluxOriginalHtml=document.documentElement.innerHTML;var src=document.querySelector('article')||document.querySelector('main')||document.body;var title=document.title||'';var text=(src.innerText||'').split(/\n{2,}/).map(x=>x.trim()).filter(x=>x.length>35);document.body.innerHTML='';var wrap=document.createElement('main');wrap.style.cssText='max-width:760px;margin:24px auto;padding:24px;font:${readerFontSize}px/1.75 Georgia,serif;background:${bg};color:${fg};min-height:100vh';var h=document.createElement('h1');h.textContent=title;wrap.appendChild(h);text.forEach(x=>{var p=document.createElement('p');p.textContent=x;wrap.appendChild(p)});document.body.appendChild(wrap)})();"""
            else """(function(){if(window.__fluxReaderActive&&window.__fluxOriginalHtml){document.documentElement.innerHTML=window.__fluxOriginalHtml;window.__fluxReaderActive=false}})();"""
        w.evaluateJavascript(js, null)
    }

    private fun chooseReaderAppearance() {
        val options = arrayOf("Small · Light", "Medium · Light", "Large · Light", "Small · Dark", "Medium · Dark", "Large · Dark")
        val size = if (readerFontSize <= 18) 0 else if (readerFontSize >= 23) 2 else 1
        val selected = size + if (readerDark) 3 else 0
        AlertDialog.Builder(this).setTitle("Reader appearance").setSingleChoiceItems(options, selected) { dialog, which ->
            readerFontSize = when (which % 3) { 0 -> 18; 2 -> 23; else -> 20 }
            readerDark = which >= 3
            prefs.edit().putInt("reader_font_size", readerFontSize).putBoolean("reader_dark", readerDark).apply()
            dialog.dismiss()
            applyReaderMode()
            if (cur.kind == "settings") buildPage("settings", false)
        }.setNegativeButton("Cancel", null).show()
    }

    private fun applyPageTheme(w: WebView? = cur.web) {
        if (w == null) return
        val js = if (darkPageEnabled) """(function(){var s=document.getElementById('flux-dark-style');if(!s){s=document.createElement('style');s.id='flux-dark-style';document.head.appendChild(s)}s.textContent='html{filter:invert(1) hue-rotate(180deg)!important;background:#111!important}img,video,iframe{filter:invert(1) hue-rotate(180deg)!important}';})();"""
            else """(function(){var s=document.getElementById('flux-dark-style');if(s)s.remove();})();"""
        w.evaluateJavascript(js, null)
    }

    private fun applyNightFilter(w: WebView? = cur.web) {
        if (w == null) return
        val js = if (nightFilterEnabled) """(function(){var s=document.getElementById('flux-night-style');if(!s){s=document.createElement('style');s.id='flux-night-style';document.head.appendChild(s)}s.textContent='body:after{content:"";position:fixed;inset:0;background:rgba(255,150,40,.12);pointer-events:none;z-index:2147483647}';})();"""
            else """(function(){var s=document.getElementById('flux-night-style');if(s)s.remove();})();"""
        w.evaluateJavascript(js, null)
    }

    private fun saveReadLater() {
        val w = cur.web
        if (cur.kind != "site" || w == null || cur.isPrivate) { Toast.makeText(this, "Open a normal website tab first", Toast.LENGTH_SHORT).show(); return }
        val id = System.currentTimeMillis().toString()
        w.evaluateJavascript("(function(){return document.documentElement.outerHTML})()") { html ->
            try {
                val decoded = try { JSONObject("{\"html\":" + html + "}").getString("html") } catch (_: Exception) { html.trim('"') }
                val file = File(filesDir, "read_$id.html")
                file.writeText(decoded)
                val arr = JSONArray(prefs.getString("read_later", "[]"))
                arr.put(JSONObject().put("id", id).put("title", cur.title).put("url", cur.url).put("file", file.name))
                prefs.edit().putString("read_later", arr.toString()).apply()
                Toast.makeText(this, "Saved for offline reading", Toast.LENGTH_SHORT).show()
            } catch (_: Exception) { Toast.makeText(this, "Could not save page", Toast.LENGTH_SHORT).show() }
        }
    }

    private fun pageReadLater() {
        content.addView(header("Read Later"))
        val arr = try { JSONArray(prefs.getString("read_later", "[]")) } catch (_: Exception) { JSONArray() }
        content.addView(card {
            if (arr.length() == 0) addView(empty("No saved pages yet"))
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                addView(row(lead(0xFF0A84FF.toInt(), R.drawable.ic_clock), o.optString("title", "Saved page"),
                    o.optString("url"), iconBtn(R.drawable.ic_close) {
                        File(filesDir, o.optString("file")).delete()
                        val next = JSONArray()
                        for (j in 0 until arr.length()) if (j != i) next.put(arr.getJSONObject(j))
                        prefs.edit().putString("read_later", next.toString()).apply()
                        buildPage("readlater")
                    }) {
                    val file = File(filesDir, o.optString("file"))
                    if (file.exists()) {
                        val html = file.readText()
                        val t = Tab(nextId++); tabs.add(t); cur = t; t.kind = "site"
                        t.web = newWeb(t); render()
                        t.web?.loadDataWithBaseURL(o.optString("url"), html, "text/html", "UTF-8", null)
                    } else Toast.makeText(this@MainActivity, "Saved copy is missing", Toast.LENGTH_SHORT).show()
                })
            }
        }, topGap())
    }

    private fun pageNews() {
        content.addView(header("Latest News", "Refresh") { fetchNews(true) })
        val body = card {
            if (rssCache.isEmpty()) addView(empty("Loading free news feeds…"))
            else rssCache.take(newsVisibleCount).forEach { item ->
                val title = item.optString("title")
                val source = item.optString("source")
                val url = item.optString("url")
                val date = item.optString("date")
                val imageUrl = item.optString("image")
                val meta = source + if (date.isNotBlank()) " · " + date else ""
                val entry = LinearLayout(this@MainActivity)
                entry.orientation = LinearLayout.HORIZONTAL
                entry.gravity = Gravity.CENTER_VERTICAL
                entry.setPadding(0, dp(10), 0, dp(10))
                if (imageUrl.startsWith("http")) {
                    val thumb = ImageView(this@MainActivity)
                    thumb.scaleType = ImageView.ScaleType.CENTER_CROP
                    thumb.background = round(0x22333333, 10)
                    entry.addView(thumb, LinearLayout.LayoutParams(dp(88), dp(68)).apply { rightMargin = dp(12) })
                    Thread { try {
                        val c = java.net.URL(imageUrl).openConnection() as java.net.HttpURLConnection
                        c.connectTimeout = 3500; c.readTimeout = 3500
                        val bytes = c.inputStream.use { it.readBytes() }; c.disconnect()
                        val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        if (bitmap != null) runOnUiThread { thumb.setImageBitmap(bitmap) }
                    } catch (_: Exception) { } }.start()
                }
                val textCol = LinearLayout(this@MainActivity)
                textCol.orientation = LinearLayout.VERTICAL
                textCol.addView(tv(title, 14f, true))
                textCol.addView(tv(meta, 11f, false, .65f))
                entry.addView(textCol, LinearLayout.LayoutParams(0, -2, 1f))
                entry.setOnClickListener { go(url) }
                press(entry, .98f)
                addView(entry)
            }
            if (rssCache.size > newsVisibleCount) addView(pill("Load more") { newsVisibleCount += 12; buildPage("news", false) })
            else addView(pill("Refresh feeds") { fetchNews(true) })
        }
        content.addView(body, topGap())
        if (rssCache.isEmpty()) fetchNews(false)
    }

    private fun fetchNews(force: Boolean) {
        if (force) newsVisibleCount = 12
        Thread {
            val found = mutableListOf<JSONObject>()
            val feeds = listOf(
                "https://news.google.com/rss?hl=en-PK&gl=PK&ceid=PK:en" to "Google News",
                "https://feeds.bbci.co.uk/news/world/rss.xml" to "BBC",
                "https://www.dawn.com/feeds/home" to "Dawn"
            )
            for ((url, source) in feeds) try {
                val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
                c.connectTimeout = 5000; c.readTimeout = 5000
                val xml = c.inputStream.bufferedReader().use { it.readText() }
                val parser = android.util.Xml.newPullParser()
                parser.setInput(xml.reader())
                var event = parser.eventType
                var title = ""; var link = ""; var date = ""; var imageUrl = ""
                while (event != org.xmlpull.v1.XmlPullParser.END_DOCUMENT && found.size < 45) {
                    if (event == org.xmlpull.v1.XmlPullParser.START_TAG && (parser.name == "item" || parser.name == "entry")) { title = ""; link = ""; date = ""; imageUrl = "" }
                    if (event == org.xmlpull.v1.XmlPullParser.START_TAG && parser.name == "title") { parser.next(); title = parser.text ?: "" }
                    if (event == org.xmlpull.v1.XmlPullParser.START_TAG && (parser.name == "link" || parser.name == "guid")) {
                        val attr = parser.getAttributeValue(null, "href")
                        if (!attr.isNullOrBlank() && attr.startsWith("http")) link = attr
                        else { parser.next(); val v = parser.text ?: ""; if (v.startsWith("http")) link = v }
                    }
                    if (event == org.xmlpull.v1.XmlPullParser.START_TAG && (parser.name == "pubDate" || parser.name == "published" || parser.name == "updated")) { parser.next(); date = parser.text ?: "" }
                    if (event == org.xmlpull.v1.XmlPullParser.START_TAG && (parser.name == "thumbnail" || parser.name == "content" || parser.name == "enclosure")) {
                        val candidate = parser.getAttributeValue(null, "url")
                        if (!candidate.isNullOrBlank() && candidate.startsWith("http") && imageUrl.isBlank()) imageUrl = candidate
                    }
                    if (event == org.xmlpull.v1.XmlPullParser.END_TAG && (parser.name == "item" || parser.name == "entry") && title.isNotBlank() && link.startsWith("http"))
                        found.add(JSONObject().put("title", title).put("url", link).put("source", source).put("date", date.take(32)).put("image", imageUrl))
                    event = parser.next()
                }
            } catch (_: Exception) {}
            if (found.isNotEmpty()) {
                rssCache = found
                val a = JSONArray(); found.forEach { a.put(it) }
                prefs.edit().putString("rss_cache", a.toString()).apply()
            }
            runOnUiThread { swipe.isRefreshing = false; if (cur.kind == "news") buildPage("news", false) }
        }.start()
    }

    // ---------- pages ----------
    private fun buildPage(kind: String, animate: Boolean = true) {
        handler.removeCallbacksAndMessages(null)
        content.removeAllViews()
        content.setPadding(dp(16), dp(24), dp(16), dp(150))
        if (animate) scroll.scrollTo(0, 0)
        when (kind) {
            "home" -> pageHome()
            "news" -> pageNews()
            "readlater" -> pageReadLater()
            "history" -> {
                content.addView(header("History", "Clear") { history.clear(); saveLists(); buildPage("history") })
                content.addView(card {
                    if (history.isEmpty()) addView(empty("No history yet"))
                    else history.take(100).forEach { h ->
                        addView(row(favTile(host(h[1]), 40, 12, lead(0xFF8E8E93.toInt(), R.drawable.ic_clock)), h[0], h[1] + " · " + h.getOrElse(2) { "" }, null) { go(h[1]) })
                    }
                }, topGap())
            }
            "bookmarks" -> {
                content.addView(header("Bookmarks"))
                content.addView(card {
                    if (marks.isEmpty()) addView(empty("No bookmarks yet"))
                    else marks.toList().forEach { m ->
                        val x = iconBtn(R.drawable.ic_close) { marks.remove(m); saveLists(); buildPage("bookmarks") }
                        val item = row(favTile(host(m[1]), 40, 12, lead(0xFFFF9F0A.toInt(), R.drawable.ic_star)), m[0], m[1], x) { go(m[1]) }
                        item.setOnLongClickListener {
                            AlertDialog.Builder(this@MainActivity).setItems(arrayOf("Move up", "Move down", "Share bookmark")) { _, which ->
                                val idx = marks.indexOf(m)
                                when (which) {
                                    0 -> if (idx > 0) java.util.Collections.swap(marks, idx, idx - 1)
                                    1 -> if (idx < marks.lastIndex) java.util.Collections.swap(marks, idx, idx + 1)
                                    2 -> startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, m[1]), "Share"))
                                }
                                saveLists(); buildPage("bookmarks")
                            }.show()
                            true
                        }
                        addView(item)
                    }
                }, topGap())
            }
            "downloads" -> {
                content.addView(header("Downloads", "Open folder") { startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)) })
                val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
                var active = false
                content.addView(card {
                    if (dls.isEmpty()) addView(empty("No downloads yet"))
                    else dls.forEach { d ->
                        var info = "Saved to Downloads"
                        val customUri = d[0].startsWith("uri:")
                        val c = if (customUri) null else try { dm.query(DownloadManager.Query().setFilterById(d[0].toLong())) } catch (_: Exception) { null }
                        if (customUri) info = "Completed · Saved in Downloads"
                        if (c != null) {
                            if (c.moveToFirst()) {
                                val st = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                                val tot = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                                val got = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                                info = when (st) {
                                    DownloadManager.STATUS_SUCCESSFUL -> "Completed"
                                    DownloadManager.STATUS_FAILED -> "Failed"
                                    else -> {
                                        active = true
                                        if (tot > 0) "Downloading " + (got * 100 / tot) + "%" else "Downloading..."
                                    }
                                }
                            }
                            c.close()
                        }
                        val item = row(lead(0xFF34C759.toInt(), R.drawable.ic_download), d[1], info, null) {
                            try {
                                val uri = if (customUri) Uri.parse(d[0].removePrefix("uri:")) else dm.getUriForDownloadedFile(d[0].toLong())
                                if (uri != null) startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, contentResolver.getType(uri)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                                else startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
                            } catch (_: Exception) { startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)) }
                        }
                        item.setOnLongClickListener {
                            AlertDialog.Builder(this@MainActivity).setMessage("Remove this download from the list and device?").setPositiveButton("Delete") { _, _ ->
                                if (customUri) try { contentResolver.delete(Uri.parse(d[0].removePrefix("uri:")), null, null) } catch (_: Exception) { }
                                else try { dm.remove(d[0].toLong()) } catch (_: Exception) { }
                                dls.remove(d); saveLists(); buildPage("downloads")
                            }.setNegativeButton("Cancel", null).show()
                            true
                        }
                        addView(item)
                    }
                }, topGap())
                if (active) handler.postDelayed({
                    if (cur.kind == "downloads" && overlay.childCount == 0) buildPage("downloads", false)
                }, 1000)
            }
            "settings" -> {
                content.addView(header("Settings"))
                val sw = Switch(this)
                sw.isChecked = desktop
                sw.setOnCheckedChangeListener { _, on -> setDesktop(on) }
                val vpn = row(lead(0xFF30B0C7.toInt(), 0, "V"), "VPN", "Coming soon", null)
                vpn.alpha = .5f
                content.addView(card {
                    addView(row(lead(0xFFAF52DE.toInt(), R.drawable.ic_image), "Wallpaper", "Change the app background", null) { showWallpaperSheet() })
                    addView(row(lead(0xFF0A84FF.toInt(), R.drawable.ic_tabs), "Desktop site", "Request the desktop version of sites", sw))
                    addView(row(lead(0xFF8E8E93.toInt(), R.drawable.ic_gear), "Search engine", searchEngine, null) { chooseSearchEngine() })
                    addView(row(lead(0xFFFF453A.toInt(), R.drawable.ic_close), "Ad & popup blocker", (if (adBlockEnabled) "On" else "Off") + " · ${tabs.sumOf { it.blockedCount }} blocked", null) { toggleSetting("adblock", !adBlockEnabled) { adBlockEnabled = it; tabs.forEach { tab -> tab.web?.reload() }; buildPage("settings") } })
                    if (cur.kind == "site") addView(row(lead(0xFFFF9F0A.toInt(), 0, "S"), "Block ads on this site", if (host(cur.url) in adBlockDisabledSites) "Disabled for this site" else "Enabled for this site", null) {
                        val h = host(cur.url)
                        if (h in adBlockDisabledSites) adBlockDisabledSites.remove(h) else adBlockDisabledSites.add(h)
                        prefs.edit().putStringSet("adblock_disabled_sites", adBlockDisabledSites).apply()
                        cur.web?.reload()
                        buildPage("settings")
                    })
                    addView(row(lead(0xFF30B0C7.toInt(), 0, "D"), "Data saver", if (dataSaver) "Image requests blocked · ${tabs.sumOf { it.savedImageCount }} skipped" else "Off", null) { toggleSetting("datasaver", !dataSaver) { dataSaver = it; tabs.forEach { tab -> tab.web?.reload() }; buildPage("settings") } })
                    addView(row(lead(0xFFAF52DE.toInt(), 0, "R"), "Reader mode", if (readerEnabled) "Enabled" else "Off", null) { toggleSetting("reader", !readerEnabled) { readerEnabled = it; applyReaderMode() ; buildPage("settings") } })
                    addView(row(lead(0xFFAF52DE.toInt(), 0, "A"), "Reader appearance", "${readerFontSize}px · ${if (readerDark) "Dark" else "Light"}", null) { chooseReaderAppearance() })
                    addView(row(lead(0xFF0A84FF.toInt(), 0, "N"), "Webpage dark mode", if (darkPageEnabled) "Enabled" else "Off", null) { toggleSetting("darkpage", !darkPageEnabled) { darkPageEnabled = it; applyPageTheme(); buildPage("settings") } })
                    addView(row(lead(0xFF8E8E93.toInt(), 0, "F"), "Night filter", if (nightFilterEnabled) "Enabled" else "Off", null) { toggleSetting("nightfilter", !nightFilterEnabled) { nightFilterEnabled = it; applyNightFilter(); buildPage("settings") } })
                    addView(row(lead(0xFF34C759.toInt(), 0, "S"), "Search suggestions", if (suggestionsEnabled) "On" else "Off", null) { toggleSetting("suggestions", !suggestionsEnabled) { suggestionsEnabled = it; buildPage("settings") } })
                    addView(row(lead(0xFF30B0C7.toInt(), 0, "B"), "Biometric lock", if (biometricLock) "Private tabs and Downloads protected" else "Off", null) {
                        if (!biometricLock) authenticate("Enable biometric lock") {
                            biometricLock = true; prefs.edit().putBoolean("biometric_lock", true).apply(); buildPage("settings")
                        } else { biometricLock = false; prefs.edit().putBoolean("biometric_lock", false).apply(); buildPage("settings") }
                    })
                    addView(row(lead(0xFFFF453A.toInt(), R.drawable.ic_close), "Clear browsing data", "History, cookies and cache", null) { clearData() })
                    addView(vpn)
                }, topGap())
                val v = tv("Flux Browser 1.0", 12f, false, .5f)
                v.gravity = Gravity.CENTER
                v.setPadding(0, dp(24), 0, 0)
                content.addView(v)
            }
        }
        if (animate) for (i in 0 until content.childCount) fadeUp(content.getChildAt(i), i * 45L)
    }

    private fun pageHome() {
        val hr = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val greet = if (hr < 12) "Good morning" else if (hr < 18) "Good afternoon" else "Good evening"
        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        val tc = LinearLayout(this)
        tc.orientation = LinearLayout.VERTICAL
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo)
        logo.scaleType = ImageView.ScaleType.FIT_CENTER
        logo.setPadding(dp(6), dp(6), dp(6), dp(6))
        logo.background = round(0xFFFFFFFF.toInt(), 14)
        head.addView(logo, LinearLayout.LayoutParams(dp(50), dp(50)).apply { rightMargin = dp(12) })
        val title = tv("Flux Browser", 28f, true)
        title.maxLines = 1
        tc.addView(title)
        tc.addView(tv(greet, 15f, false, .7f))
        head.addView(tc, LinearLayout.LayoutParams(0, -2, 1f))
        val wp = iconBtn(R.drawable.ic_image) { showWallpaperSheet() }
        wp.background = round(0x33FFFFFF, 22)
        head.addView(wp, LinearLayout.LayoutParams(dp(44), dp(44)))
        content.addView(head)
        val search = tv("Search or enter address", 15f, false, .7f)
        search.setPadding(0, dp(14), 0, dp(14))
        search.setOnClickListener { urlBox.requestFocus(); showKeyboard() }
        content.addView(card { addView(search) }, topGap())
        val clip = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        val copied = clip.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()?.trim() ?: ""
        if (copied.startsWith("http://") || copied.startsWith("https://")) {
            content.addView(card { addView(row(lead(0xFF0A84FF.toInt(), 0, "↗"), "Open copied link", copied, null) { go(copied) }) }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        }
        content.addView(label("Favorites"))
        val grid = GridLayout(this)
        grid.columnCount = 4
        val savedFavs = try { JSONArray(prefs.getString("favorites", "[]")) } catch (_: Exception) { JSONArray() }
        val favoriteItems = (if (savedFavs.length() == 0) FAVS.map { Triple(it.n, it.u, it.c) } else
            (0 until savedFavs.length()).map { i -> val o = savedFavs.getJSONObject(i); Triple(o.optString("name"), o.optString("url"), 0xFF4285F4.toInt()) }).toMutableList()
        favoriteItems.forEachIndexed { index, f ->
            val cell = LinearLayout(this)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER_HORIZONTAL
            cell.setPadding(0, dp(10), 0, dp(10))
            val ic = tv(f.first.take(1), 22f, true)
            ic.gravity = Gravity.CENTER
            ic.background = round(f.third, 18)
            cell.addView(favTile(f.second, 58, 18, ic))
            val nm = tv(f.first, 12f)
            nm.setPadding(0, dp(6), 0, 0)
            nm.gravity = Gravity.CENTER
            cell.addView(nm)
            cell.setOnClickListener { go(f.second) }
            cell.setOnLongClickListener {
                val data = ClipData.newPlainText("favorite-index", index.toString())
                cell.startDragAndDrop(data, View.DragShadowBuilder(cell), index, 0)
                true
            }
            cell.setOnDragListener { _, event ->
                when (event.action) {
                    android.view.DragEvent.ACTION_DRAG_STARTED -> true
                    android.view.DragEvent.ACTION_DROP -> {
                        val from = event.localState as? Int
                        if (from != null && from in favoriteItems.indices && from != index) {
                            val moved = favoriteItems.removeAt(from)
                            favoriteItems.add(index.coerceIn(0, favoriteItems.size), moved)
                            saveFavorites(favoriteItems.map { it.first to it.second })
                            buildPage("home")
                        }
                        true
                    }
                    android.view.DragEvent.ACTION_DRAG_ENDED -> true
                    else -> true
                }
            }
            press(cell)
            val lp = GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f))
            lp.width = 0
            lp.setGravity(Gravity.FILL_HORIZONTAL)
            grid.addView(cell, lp)
        }
        content.addView(card { addView(grid) })
        content.addView(label("Discover"))
        content.addView(card {
            addView(row(lead(0xFF1A73E8.toInt(), 0, "N"), "Latest news", "Free headlines from Google News, BBC and Dawn", null) { open("news") })
        })
    }


    // ---------- overlays ----------
    private fun copyText(value: String, message: String) {
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Flux Browser", value))
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun shareText(value: String, title: String) {
        try { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, value), title)) }
        catch (_: Exception) { Toast.makeText(this, "Sharing is unavailable", Toast.LENGTH_SHORT).show() }
    }

    private fun showActionSheet(title: String, actions: List<Pair<String, () -> Unit>>) {
        val scrimView = scrim(0x66000000)
        val sheet = GlassLayout(this)
        sheet.isClickable = true
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(18), dp(20), dp(22))
        col.addView(tv(title, 18f, true))
        actions.forEach { (label, action) ->
            val item = tv(label, 15f, true)
            item.setPadding(dp(8), dp(15), dp(8), dp(15))
            item.setOnClickListener {
                val old = scrimView
                old.animate().alpha(0f).setDuration(140).withEndAction {
                    overlay.removeView(old)
                    action()
                }.start()
            }
            press(item, .98f)
            col.addView(item)
        }
        sheet.addView(col, FrameLayout.LayoutParams(-1, -2))
        scrimView.addView(sheet, FrameLayout.LayoutParams(-1, -2).apply {
            gravity = Gravity.BOTTOM
            setMargins(dp(12), 0, dp(12), dp(28))
        })
        popSheet(sheet)
    }

    private fun closeOverlay() {
        if (overlay.childCount == 0) return
        val v = overlay.getChildAt(0)
        v.animate().alpha(0f).setDuration(170).withEndAction { overlay.removeView(v) }.start()
    }

    private fun scrim(dim: Int, anim: Boolean = true): FrameLayout {
        val s = FrameLayout(this)
        s.setBackgroundColor(dim)
        s.isClickable = true
        s.setOnClickListener { closeOverlay() }
        overlay.removeAllViews()
        overlay.addView(s, FrameLayout.LayoutParams(-1, -1))
        if (anim) { s.alpha = 0f; s.animate().alpha(1f).setDuration(200).start() }
        return s
    }

    private fun tabTitle(t: Tab): String =
        (if (t.isPrivate) "Private · " else "") + (if (t.kind == "site") t.title.ifEmpty { host(t.url) } else if (t.kind == "home") "Start Page" else t.kind.replaceFirstChar { it.uppercase() })

    private fun showTabs(animate: Boolean = true) {
        val s = scrim(0xB3000000.toInt(), animate)
        val sv = ScrollView(this)
        val grid = GridLayout(this)
        grid.columnCount = 2
        grid.setPadding(dp(12), dp(24), dp(12), dp(140))
        tabs.sortedWith(compareByDescending<Tab> { it.pinned }.thenBy { it.group.lowercase() }).forEachIndexed { idx, t ->
            val card = GlassLayout(this)
            val inner = LinearLayout(this)
            inner.orientation = LinearLayout.VERTICAL
            inner.setPadding(dp(14), dp(10), dp(8), dp(14))
            val top = LinearLayout(this)
            top.gravity = Gravity.CENTER_VERTICAL
            val sub = tv(if (t.kind == "site") host(t.url) else "Flux Browser", 12f, false, .7f)
            sub.maxLines = 1
            top.addView(sub, LinearLayout.LayoutParams(0, -2, 1f))
            top.addView(iconBtn(R.drawable.ic_close) {
                card.animate().alpha(0f).scaleX(.75f).scaleY(.75f).setDuration(180).withEndAction { closeTab(t); showTabs(true) }.start()
            }, LinearLayout.LayoutParams(dp(32), dp(32)))
            inner.addView(top)
            val ti = tv(tabTitle(t), 15f, true)
            ti.maxLines = 3
            ti.setPadding(0, dp(20), 0, 0)
            inner.addView(ti)
            if (t.isPrivate || t.pinned || t.group.isNotBlank()) {
                val meta = tv((if (t.isPrivate) "Private · " else "") + (if (t.pinned) "Pinned · " else "") + t.group, 10f, true, .7f)
                inner.addView(meta)
            }
            card.setOnLongClickListener {
                val options = arrayOf(if (t.pinned) "Unpin tab" else "Pin tab", "Set tab group", "Close tab")
                AlertDialog.Builder(this).setItems(options) { _, which ->
                    when (which) {
                        0 -> { t.pinned = !t.pinned; saveTabs(); showTabs(false) }
                        1 -> { val e = EditText(this); e.setText(t.group); AlertDialog.Builder(this).setTitle("Tab group").setView(e).setPositiveButton("Save") { _, _ -> t.group = e.text.toString().trim(); saveTabs(); showTabs(false) }.setNegativeButton("Cancel", null).show() }
                        2 -> { closeTab(t); showTabs(true) }
                    }
                }.show()
                true
            }
            if (t === cur) {
                val c = tv("Current", 11f, true)
                c.setTextColor(0xFF4DA3FF.toInt())
                inner.addView(c)
            }
            card.addView(inner, FrameLayout.LayoutParams(-1, -1))
            card.setOnClickListener { cur = t; saveTabs(); closeOverlay(); render() }
            val lp = GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f))
            lp.width = 0
            lp.setGravity(Gravity.FILL_HORIZONTAL)
            lp.height = dp(160)
            lp.setMargins(dp(6), dp(6), dp(6), dp(6))
            grid.addView(card, lp)
            if (animate) {
                card.scaleX = .85f
                card.scaleY = .85f
                card.alpha = 0f
                card.animate().scaleX(1f).scaleY(1f).alpha(1f).setStartDelay(idx * 50L).setDuration(380)
                    .setInterpolator(OvershootInterpolator(1.2f))
                    .setUpdateListener { invalidateGlass(card) }
                    .withEndAction { invalidateGlass(card) }
                    .start()
            }
        }
        sv.addView(grid)
        s.addView(sv, FrameLayout.LayoutParams(-1, -1))
        val dock = LinearLayout(this)
        dock.gravity = Gravity.CENTER
        val m = LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(6), 0, dp(6), 0) }
        dock.addView(pill("+  New Tab") { newTab() }, m)
        dock.addView(pill("Search") {
            val e = EditText(this); e.hint = "Find a tab"
            AlertDialog.Builder(this).setTitle("Search tabs").setView(e).setPositiveButton("Find") { _, _ ->
                val q = e.text.toString().lowercase()
                val match = tabs.firstOrNull { tabTitle(it).lowercase().contains(q) || it.url.lowercase().contains(q) }
                if (match != null) { cur = match; closeOverlay(); render() } else Toast.makeText(this, "No matching tab", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Cancel", null).show()
        }, m)
        dock.addView(pill("Done") { closeOverlay() }, m)
        s.addView(dock, FrameLayout.LayoutParams(-1, -2).apply { gravity = Gravity.BOTTOM; bottomMargin = dp(36) })
        if (animate) popSheet(dock)
    }

    private fun saveAsPdf() {
        val w = cur.web
        if (cur.kind != "site" || w == null) { Toast.makeText(this, "Open a webpage first", Toast.LENGTH_SHORT).show(); return }
        try {
            val pm = getSystemService(PRINT_SERVICE) as android.print.PrintManager
            val name = (cur.title.ifBlank { "Flux webpage" }).replace(Regex("[^A-Za-z0-9 _-]"), "").take(40)
            pm.print(name, w.createPrintDocumentAdapter(name), android.print.PrintAttributes.Builder().build())
        } catch (_: Exception) { Toast.makeText(this, "Could not create PDF", Toast.LENGTH_SHORT).show() }
    }

    private fun editFavorites() {
        val current = try { JSONArray(prefs.getString("favorites", "[]")) } catch (_: Exception) { JSONArray() }
        val items = mutableListOf<Pair<String, String>>()
        if (current.length() == 0) FAVS.forEach { items.add(it.n to it.u) }
        else for (i in 0 until current.length()) {
            val o = current.optJSONObject(i) ?: continue
            items.add(o.optString("name") to o.optString("url"))
        }
        val options = arrayOf("Add website", "Remove a favorite", "Move favorite up/down")
        AlertDialog.Builder(this).setTitle("Edit favorites").setItems(options) { _, which ->
            when (which) {
                0 -> {
                    val box = LinearLayout(this); box.orientation = LinearLayout.VERTICAL
                    val name = EditText(this); name.hint = "Name"
                    val url = EditText(this); url.hint = "Website URL"
                    box.addView(name); box.addView(url)
                    AlertDialog.Builder(this).setTitle("Add favorite").setView(box).setPositiveButton("Add") { _, _ ->
                        val n = name.text.toString().trim(); var u = url.text.toString().trim()
                        if (n.isNotBlank() && u.isNotBlank()) {
                            if (!u.startsWith("http")) u = "https://$u"
                            items.add(n to u); saveFavorites(items); buildPage("home")
                        }
                    }.setNegativeButton("Cancel", null).show()
                }
                1 -> AlertDialog.Builder(this).setTitle("Remove favorite").setItems(items.map { it.first }.toTypedArray()) { _, i ->
                    items.removeAt(i); saveFavorites(items); buildPage("home")
                }.show()
                2 -> AlertDialog.Builder(this).setTitle("Move favorite").setItems(items.map { it.first }.toTypedArray()) { _, i ->
                    val e = EditText(this); e.hint = "New position (1-${items.size})"; e.inputType = 2
                    AlertDialog.Builder(this).setTitle("Move ${items[i].first}").setView(e).setPositiveButton("Move") { _, _ ->
                        val to = (e.text.toString().toIntOrNull() ?: i + 1).coerceIn(1, items.size) - 1
                        val item = items.removeAt(i); items.add(to, item); saveFavorites(items); buildPage("home")
                    }.setNegativeButton("Cancel", null).show()
                }.show()
            }
        }.show()
    }

    private fun saveFavorites(items: List<Pair<String, String>>) {
        val a = JSONArray()
        items.forEach { (n, u) -> a.put(JSONObject().put("name", n).put("url", u)) }
        prefs.edit().putString("favorites", a.toString()).apply()
    }

    private fun showMenu() {
        val s = scrim(0x55000000)
        val sheet = GlassLayout(this)
        sheet.isClickable = true
        val g = GridLayout(this)
        g.columnCount = 4
        g.setPadding(dp(8), dp(10), dp(8), dp(10))
        val items: List<Triple<Int, String, () -> Unit>> = listOf(
            Triple(R.drawable.ic_plus, "New Tab") { newTab() },
            Triple(R.drawable.ic_tabs, "Private Tab") { newTab(true) },
            Triple(R.drawable.ic_clock, "News Feed") { open("news") },
            Triple(R.drawable.ic_star, "Read Later") { open("readlater") },
            Triple(R.drawable.ic_star, "Bookmark") { addBookmark() },
            Triple(R.drawable.ic_clock, "Save for later") { saveReadLater() },
            Triple(R.drawable.ic_image, "Reader mode") { readerEnabled = !readerEnabled; prefs.edit().putBoolean("reader", readerEnabled).apply(); applyReaderMode(); Toast.makeText(this, if (readerEnabled) "Reader mode on" else "Reader mode off", Toast.LENGTH_SHORT).show() },
            Triple(R.drawable.ic_download, "Save as PDF") { saveAsPdf() },
            Triple(R.drawable.ic_star, "Bookmarks") { open("bookmarks") },
            Triple(R.drawable.ic_plus, "Edit favorites") { editFavorites() },
            Triple(R.drawable.ic_clock, "History") { open("history") },
            Triple(R.drawable.ic_download, "Downloads") { open("downloads") },
            Triple(R.drawable.ic_gear, "Settings") { open("settings") },
            Triple(R.drawable.ic_image, "Wallpaper") { showWallpaperSheet() },
            Triple(R.drawable.ic_close, "Clear Data") { clearData() },
            Triple(R.drawable.ic_close, "Blocked count") { Toast.makeText(this, "Blocked ${cur.blockedCount} requests on this page", Toast.LENGTH_LONG).show() },
            Triple(R.drawable.ic_gear, "Site ad blocker") {
                if (cur.kind == "site") {
                    val h = host(cur.url)
                    if (h in adBlockDisabledSites) adBlockDisabledSites.remove(h) else adBlockDisabledSites.add(h)
                    prefs.edit().putStringSet("adblock_disabled_sites", adBlockDisabledSites).apply()
                    cur.web?.reload()
                    Toast.makeText(this, "Ad blocking " + if (h in adBlockDisabledSites) "disabled" else "enabled", Toast.LENGTH_SHORT).show()
                } else Toast.makeText(this, "Open a website first", Toast.LENGTH_SHORT).show()
            }
        )
        items.forEach { (icon, name, act) ->
            val cell = LinearLayout(this)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER_HORIZONTAL
            cell.setPadding(0, dp(12), 0, dp(10))
            val iv = ImageView(this)
            iv.setImageResource(icon)
            cell.addView(iv, LinearLayout.LayoutParams(dp(26), dp(26)))
            val t = tv(name, 11f)
            t.gravity = Gravity.CENTER
            t.setPadding(0, dp(6), 0, 0)
            cell.addView(t)
            cell.setOnClickListener { closeOverlay(); act() }
            press(cell)
            val lp = GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f))
            lp.width = 0
            lp.setGravity(Gravity.FILL_HORIZONTAL)
            g.addView(cell, lp)
        }
        sheet.addView(g, FrameLayout.LayoutParams(-1, -2))
        s.addView(sheet, FrameLayout.LayoutParams(-1, -2).apply {
            gravity = Gravity.BOTTOM
            setMargins(dp(12), 0, dp(12), dp(138))
        })
        popSheet(sheet)
    }

    private fun showWallpaperSheet() {
        val s = scrim(0x66000000)
        val sheet = GlassLayout(this)
        sheet.isClickable = true
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(18), dp(20), dp(20))
        col.addView(tv("Wallpaper", 20f, true))
        val rowP = LinearLayout(this)
        rowP.setPadding(0, dp(16), 0, dp(16))
        for (i in 0..3) {
            val iv = ImageView(this)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.setImageBitmap(presetBitmap(i, 120, 200))
            iv.background = round(0xFF000000.toInt(), 28)
            iv.clipToOutline = true
            iv.setOnClickListener {
                prefs.edit().putString("wp", "p$i").apply()
                applyWallpaper()
                closeOverlay()
            }
            rowP.addView(iv, LinearLayout.LayoutParams(dp(56), dp(56)).apply { rightMargin = dp(14) })
        }
        col.addView(rowP)
        val btns = LinearLayout(this)
        val m = LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(10) }
        btns.addView(pill("Choose from gallery") { closeOverlay(); picker.launch("image/*") }, m)
        btns.addView(pill("Reset") { prefs.edit().putString("wp", "p0").apply(); applyWallpaper(); closeOverlay() })
        col.addView(btns)
        sheet.addView(col, FrameLayout.LayoutParams(-1, -2))
        s.addView(sheet, FrameLayout.LayoutParams(-1, -2).apply { gravity = Gravity.CENTER; setMargins(dp(24), 0, dp(24), 0) })
        popSheet(sheet)
    }

    // ---------- wallpaper ----------
    private fun presetBitmap(i: Int, w: Int, h: Int): Bitmap {
        val p = PRESETS[i]
        val bm = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bm)
        c.drawColor(p[0])
        val pt = Paint(Paint.ANTI_ALIAS_FLAG)
        val xs = floatArrayOf(.1f, .95f, .1f, .9f)
        val ys = floatArrayOf(.12f, .4f, .95f, .88f)
        val rs = floatArrayOf(.85f, .8f, .9f, .6f)
        for (k in 0..3) {
            val cx = xs[k] * w
            val cy = ys[k] * h
            val r = rs[k] * w
            pt.shader = RadialGradient(cx, cy, r, p[k + 1], p[k + 1] and 0x00FFFFFF, Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, r, pt)
        }
        return bm
    }

    private fun cover(src: Bitmap, w: Int, h: Int): Bitmap {
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val sc = maxOf(w / src.width.toFloat(), h / src.height.toFloat())
        val dw = src.width * sc
        val dh = src.height * sc
        Canvas(out).drawBitmap(src, null, RectF((w - dw) / 2f, (h - dh) / 2f, (w + dw) / 2f, (h + dh) / 2f), Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }

    private fun blur(b: Bitmap): Bitmap {
        var x = b
        val target = maxOf(b.width / 14, 16)
        while (x.width / 2 >= target) x = Bitmap.createScaledBitmap(x, x.width / 2, maxOf(x.height / 2, 1), true)
        return x
    }

    private fun tintToolbarIcons(view: View) {
        if (view is ImageButton) view.setColorFilter(if (wallpaperLight && cur.kind != "site") 0xFF263247.toInt() else Color.WHITE)
        if (view is ViewGroup) for (i in 0 until view.childCount) tintToolbarIcons(view.getChildAt(i))
    }

    private fun applyWallpaper() {
        val wp = prefs.getString("wp", "p0") ?: "p0"
        var loaded: Bitmap? = null
        if (wp == "file") {
            val f = File(filesDir, "wallpaper.jpg")
            if (f.exists()) loaded = BitmapFactory.decodeFile(f.path)
        }
        val idx = if (wp.startsWith("p")) (wp.substring(1).toIntOrNull() ?: 0).coerceIn(0, 3) else 0
        val src = loaded ?: presetBitmap(idx, W, H)
        val full = cover(src, W, H)
        wall.setImageBitmap(full)
        var sum = 0L
        val sample = Bitmap.createScaledBitmap(full, 1, 1, true)
        val px = sample.getPixel(0, 0)
        val lum = (0.2126 * Color.red(px) + 0.7152 * Color.green(px) + 0.0722 * Color.blue(px)).toInt()
        wallpaperLight = lum > 155
        GlassLayout.lightWallpaper = wallpaperLight
        if (::urlBox.isInitialized) {
            urlBox.setTextColor(if (wallpaperLight && cur.kind != "site") 0xFF172033.toInt() else Color.WHITE)
            urlBox.setHintTextColor(if (wallpaperLight && cur.kind != "site") 0x99172033.toInt() else 0x99FFFFFF.toInt())
        }
        if (::ui.isInitialized) tintToolbarIcons(ui)
        sample.recycle()
        GlassLayout.blurred = blur(full)
        GlassLayout.srcW = W
        GlassLayout.srcH = H
        invalidateGlass(root)
        if (::content.isInitialized && cur.kind != "site") buildPage(cur.kind, false)
    }

    private fun setGallery(uri: Uri) {
        try {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var ss = 1
            while (o.outWidth / ss > W * 2 || o.outHeight / ss > H * 2) ss *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = ss
            val bm = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
            if (bm == null) throw Exception("decode")
            File(filesDir, "wallpaper.jpg").outputStream().use { bm.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            prefs.edit().putString("wp", "file").apply()
            applyWallpaper()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not load image", Toast.LENGTH_SHORT).show()
        }
    }
}
