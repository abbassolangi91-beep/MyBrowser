package com.example.myapp

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.*
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.webkit.*
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private const val DESKTOP_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

class Fav(val n: String, val u: String, val c: Int)

private val FAVS = listOf(
    Fav("Google", "google.com", 0xFF4285F4.toInt()), Fav("YouTube", "youtube.com", 0xFFFF0033.toInt()),
    Fav("Gmail", "mail.google.com", 0xFFEA4335.toInt()), Fav("Maps", "maps.google.com", 0xFF34A853.toInt()),
    Fav("Drive", "drive.google.com", 0xFFF9AB00.toInt()), Fav("News", "news.google.com", 0xFF1A73E8.toInt()),
    Fav("Translate", "translate.google.com", 0xFF5B8DEF.toInt()), Fav("Photos", "photos.google.com", 0xFFFF7043.toInt())
)

// base color followed by four glow colors
private val PRESETS = arrayOf(
    intArrayOf(0xFF0A0C1A.toInt(), 0xFFFF3D8B.toInt(), 0xFF2F6BFF.toInt(), 0xFF7A3DFF.toInt(), 0xFFFF8A3D.toInt()),
    intArrayOf(0xFF03111F.toInt(), 0xFF00C2FF.toInt(), 0xFF0066FF.toInt(), 0xFF00E5A8.toInt(), 0xFF5B3DFF.toInt()),
    intArrayOf(0xFF1A0B1F.toInt(), 0xFFFF6B3D.toInt(), 0xFFFF3D77.toInt(), 0xFFFFC23D.toInt(), 0xFF9B3DFF.toInt()),
    intArrayOf(0xFF04140E.toInt(), 0xFF1FD18B.toInt(), 0xFF0A8F6E.toInt(), 0xFF9BE15D.toInt(), 0xFF00B3C7.toInt())
)

class Tab(val id: Int) {
    var kind = "home"   // home, site, history, bookmarks, downloads, settings
    var web: WebView? = null
    var title = "Start Page"
    var url = ""
}

class MainActivity : AppCompatActivity() {
    private lateinit var root: FrameLayout
    private lateinit var wall: ImageView
    private lateinit var ui: FrameLayout
    private lateinit var webHost: FrameLayout
    private lateinit var scroll: ScrollView
    private lateinit var content: LinearLayout
    private lateinit var overlay: FrameLayout
    private lateinit var urlBox: EditText
    private lateinit var tabCount: TextView
    private lateinit var progress: ProgressBar
    private lateinit var cur: Tab
    private lateinit var bar: GlassLayout
    private lateinit var pillBox: GlassLayout
    private lateinit var handle: FrameLayout
    private var barShown = true
    private val barHandler = Handler(Looper.getMainLooper())
    private val hideRun = Runnable { hideBar() }
    private var padB = -1
    private val iconCache = HashMap<String, Bitmap>()
    private lateinit var prefs: SharedPreferences
    private var W = 0
    private var H = 0
    private var nextId = 1
    private var desktop = false
    private val tabs = mutableListOf<Tab>()
    private var history = mutableListOf<Array<String>>()
    private var marks = mutableListOf<Array<String>>()
    private var dls = mutableListOf<Array<String>>()
    private val handler = Handler(Looper.getMainLooper())
    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) setGallery(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        prefs = getSharedPreferences("app", MODE_PRIVATE)
        history = parse(prefs.getString("hist", null))
        marks = parse(prefs.getString("marks", null))
        dls = parse(prefs.getString("dls", null))
        desktop = prefs.getBoolean("desktop", false)
        val dm = android.util.DisplayMetrics()
        windowManager.defaultDisplay.getRealMetrics(dm)
        W = dm.widthPixels
        H = dm.heightPixels
        cur = Tab(nextId++)
        tabs.add(cur)

        root = FrameLayout(this)
        wall = ImageView(this)
        wall.scaleType = ImageView.ScaleType.FIT_XY
        root.addView(wall, FrameLayout.LayoutParams(W, H))
        ui = FrameLayout(this)
        root.addView(ui, FrameLayout.LayoutParams(-1, -1))
        webHost = FrameLayout(this)
        ui.addView(webHost, FrameLayout.LayoutParams(-1, -1))
        scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        scroll.addView(content, FrameLayout.LayoutParams(-1, -2))
        scroll.setOnScrollChangeListener { _, _, _, _, _ -> invalidateGlass(content) }
        ui.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        progress.progressTintList = ColorStateList.valueOf(0xFF4DA3FF.toInt())
        progress.visibility = View.GONE
        ui.addView(progress, FrameLayout.LayoutParams(-1, dp(3)))
        bar = buildBar()
        ui.addView(bar, FrameLayout.LayoutParams(-1, -2).apply {
            gravity = Gravity.BOTTOM
            setMargins(dp(12), 0, dp(12), dp(10))
        })
        handle = FrameLayout(this)
        val pillBar = View(this)
        pillBar.background = round(0x99FFFFFF.toInt(), 3)
        handle.addView(pillBar, FrameLayout.LayoutParams(dp(90), dp(5)).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; bottomMargin = dp(8) })
        handle.visibility = View.GONE
        handle.setOnClickListener { showBar() }
        ui.addView(handle, FrameLayout.LayoutParams(dp(150), dp(32)).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL })
        overlay = FrameLayout(this)
        ui.addView(overlay, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        ViewCompat.setOnApplyWindowInsetsListener(ui) { v, ins ->
            val sb = ins.getInsets(WindowInsetsCompat.Type.systemBars())
            val imeB = ins.getInsets(WindowInsetsCompat.Type.ime()).bottom
            @Suppress("DEPRECATION")
            val legacy = ins.systemWindowInsetBottom
            val target = maxOf(sb.bottom, imeB, legacy)
            if (padB < 0 || target == padB) {
                padB = target
                v.setPadding(0, sb.top, 0, target)
            } else {
                val a = ValueAnimator.ofInt(padB, target)
                padB = target
                a.duration = 240
                a.interpolator = DecelerateInterpolator()
                a.addUpdateListener {
                    v.setPadding(0, sb.top, 0, it.animatedValue as Int)
                    invalidateGlass(bar)
                }
                a.start()
            }
            ins
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { goBack(true) }
        })
        applyWallpaper()
        render()
        fadeUp(bar, 150)
    }

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun w1() = LinearLayout.LayoutParams(0, dp(42), 1f)
    private fun topGap() = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) }
    private fun round(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun clean(s: String) = s.replace('\t', ' ').replace('\n', ' ')
    private fun host(u: String?): String = if (u == null) "" else (Uri.parse(u).host ?: u).removePrefix("www.")

    private fun tv(s: String, sp: Float, bold: Boolean = false, a: Float = 1f): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = sp
        t.setTextColor(Color.WHITE)
        t.alpha = a
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        return t
    }

    private fun pill(label: String, click: () -> Unit): TextView {
        val t = tv(label, 14f, true)
        t.setPadding(dp(18), dp(10), dp(18), dp(10))
        t.background = round(0x33FFFFFF, 20)
        t.setOnClickListener { click() }
        press(t)
        return t
    }

    private fun iconBtn(res: Int, click: () -> Unit): ImageButton {
        val b = ImageButton(this)
        b.setImageResource(res)
        b.setBackgroundResource(android.R.color.transparent)
        b.setOnClickListener { click() }
        press(b)
        return b
    }

    private fun card(inner: LinearLayout.() -> Unit): GlassLayout {
        val g = GlassLayout(this)
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(dp(16), dp(6), dp(16), dp(6))
        l.inner()
        g.addView(l, FrameLayout.LayoutParams(-1, -2))
        return g
    }

    private fun lead(color: Int, icon: Int, letter: String = ""): View {
        val sz = dp(40)
        if (icon != 0) {
            val iv = ImageView(this)
            iv.setImageResource(icon)
            iv.setPadding(dp(9), dp(9), dp(9), dp(9))
            iv.background = round(color, 12)
            iv.layoutParams = LinearLayout.LayoutParams(sz, sz)
            return iv
        }
        val t = tv(letter, 17f, true)
        t.gravity = Gravity.CENTER
        t.background = round(color, 12)
        t.layoutParams = LinearLayout.LayoutParams(sz, sz)
        return t
    }

    private fun row(lead: View, title: String, sub: String, extra: View?, click: (() -> Unit)? = null): LinearLayout {
        val r = LinearLayout(this)
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(10), 0, dp(10))
        r.addView(lead)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(12), 0, dp(8), 0)
        val a = tv(title, 15f, true)
        a.maxLines = 1
        a.ellipsize = TextUtils.TruncateAt.END
        val b = tv(sub, 12f, false, .65f)
        b.maxLines = 1
        b.ellipsize = TextUtils.TruncateAt.END
        col.addView(a)
        col.addView(b)
        r.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        if (extra != null) r.addView(extra)
        if (click != null) { r.setOnClickListener { click() }; press(r, .97f) }
        return r
    }

    private fun header(title: String, label: String? = null, act: () -> Unit = {}): LinearLayout {
        val h = LinearLayout(this)
        h.gravity = Gravity.CENTER_VERTICAL
        h.addView(tv(title, 32f, true), LinearLayout.LayoutParams(0, -2, 1f))
        if (label != null) h.addView(pill(label, act))
        return h
    }

    private fun label(s: String): TextView {
        val t = tv(s.uppercase(), 12.5f, true, .6f)
        t.setPadding(dp(8), dp(22), 0, dp(8))
        return t
    }

    private fun empty(s: String): TextView {
        val t = tv(s, 14f, false, .6f)
        t.setPadding(0, dp(14), 0, dp(14))
        return t
    }

    private fun invalidateGlass(v: View) {
        if (v is GlassLayout) v.invalidate()
        if (v is ViewGroup) for (i in 0 until v.childCount) invalidateGlass(v.getChildAt(i))
    }

    private fun showKeyboard() {
        urlBox.post { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(urlBox, InputMethodManager.SHOW_IMPLICIT) }
    }

    private fun hideKeyboard() {
        urlBox.clearFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(urlBox.windowToken, 0)
    }

    // ---------- animation + icons ----------
    @SuppressLint("ClickableViewAccessibility")
    private fun press(v: View, s: Float = .93f) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> view.animate().scaleX(s).scaleY(s).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(2.5f)).start()
            }
            false
        }
    }

    private fun fadeUp(v: View, delay: Long = 0) {
        val target = v.alpha
        v.alpha = 0f
        v.translationY = dp(18).toFloat()
        v.animate().alpha(target).translationY(0f).setStartDelay(delay).setDuration(360)
            .setInterpolator(DecelerateInterpolator(1.6f))
            .setUpdateListener { invalidateGlass(v) }
            .withEndAction { invalidateGlass(v) }
            .start()
    }

    private fun popSheet(v: View) {
        v.translationY = dp(36).toFloat()
        v.scaleX = .96f
        v.scaleY = .96f
        v.animate().translationY(0f).scaleX(1f).scaleY(1f).setDuration(400)
            .setInterpolator(OvershootInterpolator(.9f))
            .setUpdateListener { invalidateGlass(v) }
            .withEndAction { invalidateGlass(v) }
            .start()
    }

    private fun loadIcon(domain: String, iv: ImageView) {
        val d = domain.lowercase()
        if (d.isBlank()) return
        val hit = iconCache[d]
        if (hit != null) { iv.setImageBitmap(hit); iv.visibility = View.VISIBLE; return }
        Thread {
            var bm: Bitmap? = null
            try {
                val f = File(cacheDir, "ic_" + d.replace(Regex("[^a-z0-9.]"), "_") + ".png")
                if (f.exists()) bm = BitmapFactory.decodeFile(f.path)
                if (bm == null) {
                    val c = java.net.URL("https://www.google.com/s2/favicons?domain=$d&sz=128").openConnection() as java.net.HttpURLConnection
                    c.connectTimeout = 6000
                    c.readTimeout = 6000
                    val bytes = c.inputStream.use { it.readBytes() }
                    bm = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    if (bm != null) f.writeBytes(bytes)
                }
            } catch (e: Exception) { }
            val r = bm
            if (r != null) runOnUiThread { iconCache[d] = r; iv.setImageBitmap(r); iv.visibility = View.VISIBLE }
        }.start()
    }

    /** Real site logo on a white tile; shows `fallback` until the logo loads. */
    private fun favTile(domain: String, sz: Int, rad: Int, fallback: View): FrameLayout {
        val f = FrameLayout(this)
        f.addView(fallback, FrameLayout.LayoutParams(-1, -1))
        val iv = ImageView(this)
        iv.background = round(0xFFFFFFFF.toInt(), rad)
        val p = dp(sz / 5)
        iv.setPadding(p, p, p, p)
        iv.visibility = View.GONE
        f.addView(iv, FrameLayout.LayoutParams(-1, -1))
        loadIcon(domain, iv)
        f.layoutParams = LinearLayout.LayoutParams(dp(sz), dp(sz))
        return f
    }

    private fun hideBar() {
        if (!barShown || cur.kind != "site" || urlBox.hasFocus() || overlay.childCount > 0) return
        barShown = false
        bar.animate().translationY((bar.height + dp(40)).toFloat()).alpha(0f).setDuration(280)
            .setInterpolator(DecelerateInterpolator()).setUpdateListener { invalidateGlass(bar) }.start()
        handle.visibility = View.VISIBLE
        handle.alpha = 0f
        handle.animate().alpha(1f).setDuration(280).start()
    }

    private fun showBar() {
        if (barShown) return
        barShown = true
        bar.animate().translationY(0f).alpha(1f).setDuration(320)
            .setInterpolator(OvershootInterpolator(.8f)).setUpdateListener { invalidateGlass(bar) }.start()
        handle.animate().alpha(0f).setDuration(150).withEndAction { handle.visibility = View.GONE }.start()
    }

    // ---------- storage ----------
    private fun parse(s: String?): MutableList<Array<String>> =
        (s ?: "").split("\n").filter { it.isNotBlank() }.map { it.split("\t").toTypedArray() }.filter { it.size >= 2 }.toMutableList()

    private fun saveLists() {
        prefs.edit()
            .putString("hist", history.take(200).joinToString("\n") { it.joinToString("\t") })
            .putString("marks", marks.joinToString("\n") { it.joinToString("\t") })
            .putString("dls", dls.joinToString("\n") { it.joinToString("\t") })
            .apply()
    }

    private fun addHistory(t: String, u: String) {
        if (u.isEmpty() || u.startsWith("about:")) return
        if (history.isNotEmpty() && history[0][1] == u) return
        history.add(0, arrayOf(clean(t), clean(u), SimpleDateFormat("MMM d, h:mm a", Locale.ENGLISH).format(Date())))
        if (history.size > 300) history.removeAt(history.size - 1)
        saveLists()
    }

    // ---------- bottom bar ----------
    private fun buildBar(): GlassLayout {
        val bar = GlassLayout(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(10), dp(10), dp(10), dp(4))
        urlBox = EditText(this)
        urlBox.hint = "Search or enter address"
        urlBox.setHintTextColor(0x99FFFFFF.toInt())
        urlBox.setTextColor(Color.WHITE)
        urlBox.textSize = 16f
        urlBox.background = null
        urlBox.gravity = Gravity.CENTER
        urlBox.inputType = EditorInfo.TYPE_CLASS_TEXT or EditorInfo.TYPE_TEXT_VARIATION_URI
        urlBox.imeOptions = EditorInfo.IME_ACTION_GO
        urlBox.setSelectAllOnFocus(true)
        urlBox.setOnEditorActionListener { v, id, _ ->
            if (id == EditorInfo.IME_ACTION_GO) { go(v.text.toString()); true } else false
        }
        urlBox.setOnFocusChangeListener { _, f ->
            if (f) { showBar(); barHandler.removeCallbacks(hideRun) }
            if (f && cur.kind == "site") { urlBox.setText(cur.url); urlBox.selectAll() }
            else if (!f) urlBox.setText(if (cur.kind == "site") host(cur.url) else "")
        }
        pillBox = GlassLayout(this)
        pillBox.elevation = 0f
        pillBox.addView(urlBox, FrameLayout.LayoutParams(-1, dp(44)))
        col.addView(pillBox)
        val row = LinearLayout(this)
        row.setPadding(0, dp(4), 0, 0)
        row.addView(iconBtn(R.drawable.ic_back) { goBack(false) }, w1())
        row.addView(iconBtn(R.drawable.ic_fwd) { goForward() }, w1())
        row.addView(iconBtn(R.drawable.ic_plus) { newTab() }, w1())
        val tf = FrameLayout(this)
        tf.addView(iconBtn(R.drawable.ic_tabs) { showTabs() }, FrameLayout.LayoutParams(-1, -1))
        tabCount = tv("1", 10f, true)
        tabCount.gravity = Gravity.CENTER
        tf.addView(tabCount, FrameLayout.LayoutParams(-1, -1))
        row.addView(tf, w1())
        row.addView(iconBtn(R.drawable.ic_menu) { showMenu() }, w1())
        col.addView(row)
        bar.addView(col, FrameLayout.LayoutParams(-1, -2))
        return bar
    }

    // ---------- navigation ----------
    private fun render() {
        webHost.removeAllViews()
        progress.visibility = View.GONE
        val w = cur.web
        val onSite = cur.kind == "site" && w != null
        bar.overContent = onSite
        pillBox.overContent = onSite
        showBar()
        if (cur.kind == "site" && w != null) {
            webHost.addView(w, FrameLayout.LayoutParams(-1, -1))
            webHost.visibility = View.VISIBLE
            scroll.visibility = View.GONE
            urlBox.setText(host(cur.url))
            webHost.alpha = 0f
            webHost.animate().alpha(1f).setDuration(260).start()
        } else {
            webHost.visibility = View.GONE
            scroll.visibility = View.VISIBLE
            urlBox.setText("")
            buildPage(cur.kind)
        }
        val n = tabs.size.toString()
        if (tabCount.text.toString() != n) {
            tabCount.text = n
            tabCount.animate().scaleX(1.5f).scaleY(1.5f).setDuration(120).withEndAction {
                tabCount.animate().scaleX(1f).scaleY(1f).setDuration(240).setInterpolator(OvershootInterpolator(3f)).start()
            }.start()
        }
    }

    private fun go(q: String) {
        val s = q.trim()
        if (s.isEmpty()) return
        val isUrl = Regex("^(https?://)?[\\w-]+(\\.[\\w-]+)+(:\\d+)?(/.*)?$").matches(s)
        val u = if (isUrl) (if (s.startsWith("http")) s else "https://$s") else "https://www.google.com/search?q=" + Uri.encode(s)
        if (cur.web == null) cur.web = newWeb(cur)
        cur.kind = "site"
        render()
        cur.web!!.loadUrl(u)
        hideKeyboard()
    }

    private fun goBack(system: Boolean) {
        if (overlay.childCount > 0) { closeOverlay(); return }
        val w = cur.web
        if (cur.kind == "site") {
            if (w != null && w.canGoBack()) w.goBack() else { cur.kind = "home"; render() }
        } else if (cur.kind != "home") {
            cur.kind = if (w != null && cur.url.isNotEmpty()) "site" else "home"
            render()
        } else if (system) finish()
    }

    private fun goForward() {
        val w = cur.web ?: return
        if (cur.kind == "site") { if (w.canGoForward()) w.goForward() }
        else if (cur.url.isNotEmpty()) { cur.kind = "site"; render() }
    }

    private fun open(kind: String) { cur.kind = kind; render() }

    private fun newTab() {
        cur = Tab(nextId++)
        tabs.add(cur)
        closeOverlay()
        render()
    }

    private fun closeTab(t: Tab) {
        val w = t.web
        if (w != null) { (w.parent as? ViewGroup)?.removeView(w); w.destroy() }
        tabs.remove(t)
        if (tabs.isEmpty()) { cur = Tab(nextId++); tabs.add(cur) } else if (cur === t) cur = tabs.last()
    }

    private fun applyUa(w: WebView?) {
        if (w == null) return
        w.settings.userAgentString = if (desktop) DESKTOP_UA else null
        w.settings.useWideViewPort = desktop
        w.settings.loadWithOverviewMode = desktop
    }

    private fun setDesktop(on: Boolean) {
        desktop = on
        prefs.edit().putBoolean("desktop", on).apply()
        tabs.forEach { applyUa(it.web); it.web?.reload() }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun newWeb(t: Tab): WebView {
        val w = WebView(this)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.builtInZoomControls = true
        w.settings.displayZoomControls = false
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)
        applyUa(w)
        var lastY = 0f
        var acc = 0f
        w.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { lastY = e.rawY; acc = 0f }
                MotionEvent.ACTION_MOVE -> {
                    val dy = e.rawY - lastY
                    lastY = e.rawY
                    acc = if (acc * dy >= 0f) acc + dy else dy
                    if (acc < -dp(26)) hideBar() else if (acc > dp(26)) showBar()
                }
            }
            false
        }
        w.webViewClient = object : WebViewClient() {
            override fun onPageStarted(v: WebView?, u: String?, f: Bitmap?) {
                t.url = u ?: ""
                if (t === cur) {
                    progress.progress = 0
                    progress.visibility = View.VISIBLE
                    if (t.kind == "site" && !urlBox.hasFocus()) urlBox.setText(host(u))
                }
            }
            override fun onPageFinished(v: WebView?, u: String?) {
                t.title = v?.title ?: host(u)
                t.url = u ?: t.url
                if (t === cur) {
                    progress.visibility = View.GONE
                    barHandler.removeCallbacks(hideRun)
                    barHandler.postDelayed(hideRun, 1800)
                }
                addHistory(t.title, t.url)
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView?, p: Int) { if (t === cur) progress.progress = p }
        }
        w.setDownloadListener { u, ua, cd, mime, _ -> startDownload(u, ua, cd, mime) }
        return w
    }

    private fun startDownload(u: String, ua: String?, cd: String?, mime: String?) {
        val name = URLUtil.guessFileName(u, cd, mime)
        try {
            val req = DownloadManager.Request(Uri.parse(u))
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            if (mime != null) req.setMimeType(mime)
            if (ua != null) req.addRequestHeader("User-Agent", ua)
            val ck = CookieManager.getInstance().getCookie(u)
            if (ck != null) req.addRequestHeader("Cookie", ck)
            val id = (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            dls.add(0, arrayOf(id.toString(), clean(name)))
            saveLists()
            Toast.makeText(this, "Downloading $name", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Download failed", Toast.LENGTH_SHORT).show()
        }
    }

    private fun clearData() {
        history.clear()
        saveLists()
        CookieManager.getInstance().removeAllCookies(null)
        WebStorage.getInstance().deleteAllData()
        tabs.forEach { it.web?.clearCache(true) }
        Toast.makeText(this, "Browsing data cleared", Toast.LENGTH_SHORT).show()
        if (cur.kind != "site") buildPage(cur.kind)
    }

    private fun addBookmark() {
        if (cur.kind == "site" && cur.url.isNotEmpty()) {
            if (marks.none { it[1] == cur.url }) marks.add(0, arrayOf(clean(cur.title), clean(cur.url)))
            saveLists()
            Toast.makeText(this, "Bookmark added", Toast.LENGTH_SHORT).show()
        } else Toast.makeText(this, "Open a website first", Toast.LENGTH_SHORT).show()
    }

    // ---------- pages ----------
    private fun buildPage(kind: String, animate: Boolean = true) {
        handler.removeCallbacksAndMessages(null)
        content.removeAllViews()
        content.setPadding(dp(16), dp(24), dp(16), dp(150))
        if (animate) scroll.scrollTo(0, 0)
        when (kind) {
            "home" -> pageHome()
            "history" -> {
                content.addView(header("History", "Clear") { history.clear(); saveLists(); buildPage("history") })
                content.addView(card {
                    if (history.isEmpty()) addView(empty("No history yet"))
                    else history.take(100).forEach { h ->
                        addView(row(favTile(host(h[1]), 40, 12, lead(0xFF8E8E93.toInt(), R.drawable.ic_clock)), h[0], h[1] + " · " + h.getOrElse(2) { "" }, null) { go(h[1]) })
                    }
                }, topGap())
            }
            "bookmarks" -> {
                content.addView(header("Bookmarks"))
                content.addView(card {
                    if (marks.isEmpty()) addView(empty("No bookmarks yet"))
                    else marks.toList().forEach { m ->
                        val x = iconBtn(R.drawable.ic_close) { marks.remove(m); saveLists(); buildPage("bookmarks") }
                        addView(row(favTile(host(m[1]), 40, 12, lead(0xFFFF9F0A.toInt(), R.drawable.ic_star)), m[0], m[1], x) { go(m[1]) })
                    }
                }, topGap())
            }
            "downloads" -> {
                content.addView(header("Downloads", "Open folder") { startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)) })
                val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
                var active = false
                content.addView(card {
                    if (dls.isEmpty()) addView(empty("No downloads yet"))
                    else dls.forEach { d ->
                        var info = "Saved to Downloads"
                        val c = dm.query(DownloadManager.Query().setFilterById(d[0].toLong()))
                        if (c != null) {
                            if (c.moveToFirst()) {
                                val st = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                                val tot = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                                val got = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                                info = when (st) {
                                    DownloadManager.STATUS_SUCCESSFUL -> "Completed"
                                    DownloadManager.STATUS_FAILED -> "Failed"
                                    else -> {
                                        active = true
                                        if (tot > 0) "Downloading " + (got * 100 / tot) + "%" else "Downloading..."
                                    }
                                }
                            }
                            c.close()
                        }
                        addView(row(lead(0xFF34C759.toInt(), R.drawable.ic_download), d[1], info, null) {
                            startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
                        })
                    }
                }, topGap())
                if (active) handler.postDelayed({
                    if (cur.kind == "downloads" && overlay.childCount == 0) buildPage("downloads", false)
                }, 1000)
            }
            "settings" -> {
                content.addView(header("Settings"))
                val sw = Switch(this)
                sw.isChecked = desktop
                sw.setOnCheckedChangeListener { _, on -> setDesktop(on) }
                val vpn = row(lead(0xFF30B0C7.toInt(), 0, "V"), "VPN", "Coming soon", null)
                vpn.alpha = .5f
                content.addView(card {
                    addView(row(lead(0xFFAF52DE.toInt(), R.drawable.ic_image), "Wallpaper", "Change the app background", null) { showWallpaperSheet() })
                    addView(row(lead(0xFF0A84FF.toInt(), R.drawable.ic_tabs), "Desktop site", "Request the desktop version of sites", sw))
                    addView(row(lead(0xFF8E8E93.toInt(), R.drawable.ic_gear), "Search engine", "Google", null))
                    addView(row(lead(0xFFFF453A.toInt(), R.drawable.ic_close), "Clear browsing data", "History, cookies and cache", null) { clearData() })
                    addView(vpn)
                }, topGap())
                val v = tv("Flux Browser 1.0", 12f, false, .5f)
                v.gravity = Gravity.CENTER
                v.setPadding(0, dp(24), 0, 0)
                content.addView(v)
            }
        }
        if (animate) for (i in 0 until content.childCount) fadeUp(content.getChildAt(i), i * 45L)
    }

    private fun pageHome() {
        val hr = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val greet = if (hr < 12) "Good morning" else if (hr < 18) "Good afternoon" else "Good evening"
        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        val tc = LinearLayout(this)
        tc.orientation = LinearLayout.VERTICAL
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo)
        logo.scaleType = ImageView.ScaleType.FIT_CENTER
        logo.setPadding(dp(6), dp(6), dp(6), dp(6))
        logo.background = round(0xFFFFFFFF.toInt(), 14)
        head.addView(logo, LinearLayout.LayoutParams(dp(50), dp(50)).apply { rightMargin = dp(12) })
        val title = tv("Flux Browser", 28f, true)
        title.maxLines = 1
        tc.addView(title)
        tc.addView(tv(greet, 15f, false, .7f))
        head.addView(tc, LinearLayout.LayoutParams(0, -2, 1f))
        val wp = iconBtn(R.drawable.ic_image) { showWallpaperSheet() }
        wp.background = round(0x33FFFFFF, 22)
        head.addView(wp, LinearLayout.LayoutParams(dp(44), dp(44)))
        content.addView(head)
        val search = tv("Search or enter address", 15f, false, .7f)
        search.setPadding(0, dp(14), 0, dp(14))
        search.setOnClickListener { urlBox.requestFocus(); showKeyboard() }
        content.addView(card { addView(search) }, topGap())
        content.addView(label("Favorites"))
        val grid = GridLayout(this)
        grid.columnCount = 4
        FAVS.forEach { f ->
            val cell = LinearLayout(this)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER_HORIZONTAL
            cell.setPadding(0, dp(10), 0, dp(10))
            val ic = tv(f.n.substring(0, 1), 22f, true)
            ic.gravity = Gravity.CENTER
            ic.background = round(f.c, 18)
            cell.addView(favTile(f.u, 58, 18, ic))
            val nm = tv(f.n, 12f)
            nm.setPadding(0, dp(6), 0, 0)
            nm.gravity = Gravity.CENTER
            cell.addView(nm)
            cell.setOnClickListener { go(f.u) }
            press(cell)
            val lp = GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f))
            lp.width = 0
            lp.setGravity(Gravity.FILL_HORIZONTAL)
            grid.addView(cell, lp)
        }
        content.addView(card { addView(grid) })
        content.addView(label("Recent"))
        content.addView(card {
            if (history.isEmpty()) addView(empty("No history yet"))
            else history.take(3).forEach { h ->
                addView(row(favTile(host(h[1]), 40, 12, lead(0xFF8E8E93.toInt(), R.drawable.ic_clock)), h[0], h[1], null) { go(h[1]) })
            }
        })
    }

    // ---------- overlays ----------
    private fun closeOverlay() {
        if (overlay.childCount == 0) return
        val v = overlay.getChildAt(0)
        v.animate().alpha(0f).setDuration(170).withEndAction { overlay.removeView(v) }.start()
    }

    private fun scrim(dim: Int, anim: Boolean = true): FrameLayout {
        val s = FrameLayout(this)
        s.setBackgroundColor(dim)
        s.isClickable = true
        s.setOnClickListener { closeOverlay() }
        overlay.removeAllViews()
        overlay.addView(s, FrameLayout.LayoutParams(-1, -1))
        if (anim) { s.alpha = 0f; s.animate().alpha(1f).setDuration(200).start() }
        return s
    }

    private fun tabTitle(t: Tab): String =
        if (t.kind == "site") t.title.ifEmpty { host(t.url) } else if (t.kind == "home") "Start Page" else t.kind.replaceFirstChar { it.uppercase() }

    private fun showTabs(animate: Boolean = true) {
        val s = scrim(0xB3000000.toInt(), animate)
        val sv = ScrollView(this)
        val grid = GridLayout(this)
        grid.columnCount = 2
        grid.setPadding(dp(12), dp(24), dp(12), dp(140))
        tabs.forEachIndexed { idx, t ->
            val card = GlassLayout(this)
            val inner = LinearLayout(this)
            inner.orientation = LinearLayout.VERTICAL
            inner.setPadding(dp(14), dp(10), dp(8), dp(14))
            val top = LinearLayout(this)
            top.gravity = Gravity.CENTER_VERTICAL
            val sub = tv(if (t.kind == "site") host(t.url) else "Flux Browser", 12f, false, .7f)
            sub.maxLines = 1
            top.addView(sub, LinearLayout.LayoutParams(0, -2, 1f))
            top.addView(iconBtn(R.drawable.ic_close) { closeTab(t); showTabs(false) }, LinearLayout.LayoutParams(dp(32), dp(32)))
            inner.addView(top)
            val ti = tv(tabTitle(t), 15f, true)
            ti.maxLines = 3
            ti.setPadding(0, dp(20), 0, 0)
            inner.addView(ti)
            if (t === cur) {
                val c = tv("Current", 11f, true)
                c.setTextColor(0xFF4DA3FF.toInt())
                inner.addView(c)
            }
            card.addView(inner, FrameLayout.LayoutParams(-1, -1))
            card.setOnClickListener { cur = t; closeOverlay(); render() }
            val lp = GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f))
            lp.width = 0
            lp.setGravity(Gravity.FILL_HORIZONTAL)
            lp.height = dp(160)
            lp.setMargins(dp(6), dp(6), dp(6), dp(6))
            grid.addView(card, lp)
            if (animate) {
                card.scaleX = .85f
                card.scaleY = .85f
                card.alpha = 0f
                card.animate().scaleX(1f).scaleY(1f).alpha(1f).setStartDelay(idx * 50L).setDuration(380)
                    .setInterpolator(OvershootInterpolator(1.2f))
                    .setUpdateListener { invalidateGlass(card) }
                    .withEndAction { invalidateGlass(card) }
                    .start()
            }
        }
        sv.addView(grid)
        s.addView(sv, FrameLayout.LayoutParams(-1, -1))
        val dock = LinearLayout(this)
        dock.gravity = Gravity.CENTER
        val m = LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(6), 0, dp(6), 0) }
        dock.addView(pill("+  New Tab") { newTab() }, m)
        dock.addView(pill("Done") { closeOverlay() }, m)
        s.addView(dock, FrameLayout.LayoutParams(-1, -2).apply { gravity = Gravity.BOTTOM; bottomMargin = dp(36) })
        if (animate) popSheet(dock)
    }

    private fun showMenu() {
        val s = scrim(0x55000000)
        val sheet = GlassLayout(this)
        sheet.isClickable = true
        val g = GridLayout(this)
        g.columnCount = 4
        g.setPadding(dp(8), dp(10), dp(8), dp(10))
        val items: List<Triple<Int, String, () -> Unit>> = listOf(
            Triple(R.drawable.ic_plus, "New Tab") { newTab() },
            Triple(R.drawable.ic_star, "Bookmark") { addBookmark() },
            Triple(R.drawable.ic_star, "Bookmarks") { open("bookmarks") },
            Triple(R.drawable.ic_clock, "History") { open("history") },
            Triple(R.drawable.ic_download, "Downloads") { open("downloads") },
            Triple(R.drawable.ic_gear, "Settings") { open("settings") },
            Triple(R.drawable.ic_image, "Wallpaper") { showWallpaperSheet() },
            Triple(R.drawable.ic_close, "Clear Data") { clearData() }
        )
        items.forEach { (icon, name, act) ->
            val cell = LinearLayout(this)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER_HORIZONTAL
            cell.setPadding(0, dp(12), 0, dp(10))
            val iv = ImageView(this)
            iv.setImageResource(icon)
            cell.addView(iv, LinearLayout.LayoutParams(dp(26), dp(26)))
            val t = tv(name, 11f)
            t.gravity = Gravity.CENTER
            t.setPadding(0, dp(6), 0, 0)
            cell.addView(t)
            cell.setOnClickListener { closeOverlay(); act() }
            press(cell)
            val lp = GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f))
            lp.width = 0
            lp.setGravity(Gravity.FILL_HORIZONTAL)
            g.addView(cell, lp)
        }
        sheet.addView(g, FrameLayout.LayoutParams(-1, -2))
        s.addView(sheet, FrameLayout.LayoutParams(-1, -2).apply {
            gravity = Gravity.BOTTOM
            setMargins(dp(12), 0, dp(12), dp(138))
        })
        popSheet(sheet)
    }

    private fun showWallpaperSheet() {
        val s = scrim(0x66000000)
        val sheet = GlassLayout(this)
        sheet.isClickable = true
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(18), dp(20), dp(20))
        col.addView(tv("Wallpaper", 20f, true))
        val rowP = LinearLayout(this)
        rowP.setPadding(0, dp(16), 0, dp(16))
        for (i in 0..3) {
            val iv = ImageView(this)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.setImageBitmap(presetBitmap(i, 120, 200))
            iv.background = round(0xFF000000.toInt(), 28)
            iv.clipToOutline = true
            iv.setOnClickListener {
                prefs.edit().putString("wp", "p$i").apply()
                applyWallpaper()
                closeOverlay()
            }
            rowP.addView(iv, LinearLayout.LayoutParams(dp(56), dp(56)).apply { rightMargin = dp(14) })
        }
        col.addView(rowP)
        val btns = LinearLayout(this)
        val m = LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(10) }
        btns.addView(pill("Choose from gallery") { closeOverlay(); picker.launch("image/*") }, m)
        btns.addView(pill("Reset") { prefs.edit().putString("wp", "p0").apply(); applyWallpaper(); closeOverlay() })
        col.addView(btns)
        sheet.addView(col, FrameLayout.LayoutParams(-1, -2))
        s.addView(sheet, FrameLayout.LayoutParams(-1, -2).apply { gravity = Gravity.CENTER; setMargins(dp(24), 0, dp(24), 0) })
        popSheet(sheet)
    }

    // ---------- wallpaper ----------
    private fun presetBitmap(i: Int, w: Int, h: Int): Bitmap {
        val p = PRESETS[i]
        val bm = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bm)
        c.drawColor(p[0])
        val pt = Paint(Paint.ANTI_ALIAS_FLAG)
        val xs = floatArrayOf(.1f, .95f, .1f, .9f)
        val ys = floatArrayOf(.12f, .4f, .95f, .88f)
        val rs = floatArrayOf(.85f, .8f, .9f, .6f)
        for (k in 0..3) {
            val cx = xs[k] * w
            val cy = ys[k] * h
            val r = rs[k] * w
            pt.shader = RadialGradient(cx, cy, r, p[k + 1], p[k + 1] and 0x00FFFFFF, Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, r, pt)
        }
        return bm
    }

    private fun cover(src: Bitmap, w: Int, h: Int): Bitmap {
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val sc = maxOf(w / src.width.toFloat(), h / src.height.toFloat())
        val dw = src.width * sc
        val dh = src.height * sc
        Canvas(out).drawBitmap(src, null, RectF((w - dw) / 2f, (h - dh) / 2f, (w + dw) / 2f, (h + dh) / 2f), Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }

    private fun blur(b: Bitmap): Bitmap {
        var x = b
        val target = maxOf(b.width / 14, 16)
        while (x.width / 2 >= target) x = Bitmap.createScaledBitmap(x, x.width / 2, maxOf(x.height / 2, 1), true)
        return x
    }

    private fun applyWallpaper() {
        val wp = prefs.getString("wp", "p0") ?: "p0"
        var loaded: Bitmap? = null
        if (wp == "file") {
            val f = File(filesDir, "wallpaper.jpg")
            if (f.exists()) loaded = BitmapFactory.decodeFile(f.path)
        }
        val idx = if (wp.startsWith("p")) (wp.substring(1).toIntOrNull() ?: 0).coerceIn(0, 3) else 0
        val src = loaded ?: presetBitmap(idx, W, H)
        val full = cover(src, W, H)
        wall.setImageBitmap(full)
        GlassLayout.blurred = blur(full)
        GlassLayout.srcW = W
        GlassLayout.srcH = H
        invalidateGlass(root)
    }

    private fun setGallery(uri: Uri) {
        try {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var ss = 1
            while (o.outWidth / ss > W * 2 || o.outHeight / ss > H * 2) ss *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = ss
            val bm = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
            if (bm == null) throw Exception("decode")
            File(filesDir, "wallpaper.jpg").outputStream().use { bm.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            prefs.edit().putString("wp", "file").apply()
            applyWallpaper()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not load image", Toast.LENGTH_SHORT).show()
        }
    }
}
