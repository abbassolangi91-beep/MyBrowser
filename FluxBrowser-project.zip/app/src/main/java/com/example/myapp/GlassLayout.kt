package com.example.myapp

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout

/**
 * Liquid-glass panel: blurred + saturated wallpaper behind it, light gathering at the top and left,
 * a soft corner glow, a diagonal shine streak, a double rim light and a soft shadow.
 * When it floats over a web page (overContent) it becomes a translucent dark frost instead.
 */
class GlassLayout @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : FrameLayout(context, attrs) {
    companion object {
        var blurred: Bitmap? = null
        var srcW = 0
        var srcH = 0
    }

    var overContent = false
        set(v) { field = v; invalidate() }

    private val path = Path()
    private val rect = RectF()
    private val shine = Path()
    private val loc = IntArray(2)
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG).apply {
        colorFilter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(1.6f) })
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

    init {
        setWillNotDraw(false)
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, radius(view.width.toFloat(), view.height.toFloat()))
            }
        }
        elevation = 10f * resources.displayMetrics.density
        outlineAmbientShadowColor = 0x66101030
        outlineSpotShadowColor = 0x66101030
    }

    private fun radius(w: Float, h: Float) = minOf(28f * resources.displayMetrics.density, minOf(w, h) / 2f)

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        invalidateOutline()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        val d = resources.displayMetrics.density
        val r = radius(w, h)
        rect.set(0f, 0f, w, h)
        path.reset()
        path.addRoundRect(rect, r, r, Path.Direction.CW)
        canvas.save()
        canvas.clipPath(path)

        // 1. body: blurred wallpaper (or frosted dark when over a web page)
        val bmp = blurred
        if (bmp != null && !overContent) {
            getLocationInWindow(loc)
            val dst = RectF(-loc[0].toFloat(), -loc[1].toFloat(), -loc[0] + srcW.toFloat(), -loc[1] + srcH.toFloat())
            canvas.drawBitmap(bmp, null, dst, bmpPaint)
            fill.color = 0x18000000
            canvas.drawRect(rect, fill)
            fill.color = 0x26FFFFFF
            canvas.drawRect(rect, fill)
        } else {
            fill.color = 0x9A12121A.toInt()
            canvas.drawRect(rect, fill)
            fill.color = 0x1AFFFFFF
            canvas.drawRect(rect, fill)
        }

        // 2. light gathering from the top
        fill.shader = LinearGradient(0f, 0f, 0f, h, intArrayOf(0x4DFFFFFF, 0x10FFFFFF, 0x00FFFFFF), floatArrayOf(0f, .38f, 1f), Shader.TileMode.CLAMP)
        canvas.drawRect(rect, fill)
        // 3. light gathering from the left side
        fill.shader = LinearGradient(0f, 0f, w * .35f, 0f, intArrayOf(0x33FFFFFF, 0x00FFFFFF), null, Shader.TileMode.CLAMP)
        canvas.drawRect(rect, fill)
        // 4. soft glow in the top-left corner
        fill.shader = RadialGradient(w * .14f, -h * .1f, maxOf(w, h) * .75f, 0x5CFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
        canvas.drawRect(rect, fill)
        // 5. diagonal shine streak
        shine.reset()
        shine.moveTo(w * .42f, 0f)
        shine.lineTo(w * .62f, 0f)
        shine.lineTo(w * .22f, h)
        shine.lineTo(w * .02f, h)
        shine.close()
        fill.shader = LinearGradient(w * .02f, 0f, w * .62f, 0f, intArrayOf(0x00FFFFFF, 0x1FFFFFFF, 0x00FFFFFF), floatArrayOf(0f, .5f, 1f), Shader.TileMode.CLAMP)
        canvas.drawPath(shine, fill)
        fill.shader = null
        canvas.restore()

        // 6. rim light: bright top-left, dim middle, soft bottom-right
        val sw = 1.3f * d
        line.strokeWidth = sw
        line.shader = LinearGradient(0f, 0f, w, h, intArrayOf(0xD9FFFFFF.toInt(), 0x22FFFFFF, 0x22FFFFFF, 0x8CFFFFFF.toInt()), floatArrayOf(0f, .35f, .65f, 1f), Shader.TileMode.CLAMP)
        rect.set(sw / 2f, sw / 2f, w - sw / 2f, h - sw / 2f)
        canvas.drawRoundRect(rect, r, r, line)
        // 7. thin inner highlight just under the top edge
        line.strokeWidth = .8f * d
        line.shader = LinearGradient(0f, 0f, 0f, h * .55f, intArrayOf(0x73FFFFFF, 0x00FFFFFF), null, Shader.TileMode.CLAMP)
        rect.set(sw * 1.7f, sw * 1.7f, w - sw * 1.7f, h - sw * 1.7f)
        canvas.drawRoundRect(rect, maxOf(r - sw * 1.7f, 0f), maxOf(r - sw * 1.7f, 0f), line)
        line.shader = null
    }
}
